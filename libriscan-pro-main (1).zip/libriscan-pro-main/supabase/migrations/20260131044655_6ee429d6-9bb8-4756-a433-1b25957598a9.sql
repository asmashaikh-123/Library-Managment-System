-- Fix warn-level security issues

-- 1. Fix activity_logs INSERT policy to validate user_id matches authenticated user
DROP POLICY IF EXISTS "Authenticated users can insert activity_logs" ON activity_logs;

CREATE POLICY "Users can insert own activity_logs"
ON activity_logs FOR INSERT TO authenticated
WITH CHECK (user_id = auth.uid() OR user_id IS NULL);

-- 2. Fix notifications INSERT policy (also has WITH CHECK true)
DROP POLICY IF EXISTS "Authenticated users can insert notifications" ON notifications;

CREATE POLICY "Users can insert own notifications"
ON notifications FOR INSERT TO authenticated
WITH CHECK (user_id = auth.uid() OR user_id IS NULL);