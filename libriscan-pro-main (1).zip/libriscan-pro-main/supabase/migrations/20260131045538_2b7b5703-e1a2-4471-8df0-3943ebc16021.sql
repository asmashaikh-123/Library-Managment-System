-- Fix activity_logs exposure - restrict SELECT to admins and librarians only
DROP POLICY IF EXISTS "Authenticated users can read activity_logs" ON activity_logs;

CREATE POLICY "Admins and librarians can read activity_logs"
ON activity_logs FOR SELECT TO authenticated
USING (has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'librarian'));