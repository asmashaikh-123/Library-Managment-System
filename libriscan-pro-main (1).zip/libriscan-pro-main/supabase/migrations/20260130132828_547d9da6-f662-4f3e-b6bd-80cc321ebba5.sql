-- =====================================================
-- FIX 1: Tighten RLS policies on members table
-- =====================================================

-- Drop overly permissive policies
DROP POLICY IF EXISTS "Authenticated users can read members" ON public.members;
DROP POLICY IF EXISTS "Authenticated users can insert members" ON public.members;
DROP POLICY IF EXISTS "Authenticated users can update members" ON public.members;
DROP POLICY IF EXISTS "Authenticated users can delete members" ON public.members;

-- All staff can view members (needed for library operations)
CREATE POLICY "All staff can view members" ON public.members
  FOR SELECT TO authenticated USING (true);

-- Only admins and librarians can manage members
CREATE POLICY "Admins and librarians can insert members" ON public.members
  FOR INSERT TO authenticated
  WITH CHECK (has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'librarian'));

CREATE POLICY "Admins and librarians can update members" ON public.members
  FOR UPDATE TO authenticated
  USING (has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'librarian'));

CREATE POLICY "Admins and librarians can delete members" ON public.members
  FOR DELETE TO authenticated
  USING (has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'librarian'));

-- =====================================================
-- FIX 2: Tighten RLS policies on books table
-- =====================================================

-- Drop overly permissive policies
DROP POLICY IF EXISTS "Authenticated users can read books" ON public.books;
DROP POLICY IF EXISTS "Authenticated users can insert books" ON public.books;
DROP POLICY IF EXISTS "Authenticated users can update books" ON public.books;
DROP POLICY IF EXISTS "Authenticated users can delete books" ON public.books;

-- All staff can view books
CREATE POLICY "All staff can view books" ON public.books
  FOR SELECT TO authenticated USING (true);

-- Only admins and librarians can manage books
CREATE POLICY "Admins and librarians can insert books" ON public.books
  FOR INSERT TO authenticated
  WITH CHECK (has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'librarian'));

CREATE POLICY "Admins and librarians can update books" ON public.books
  FOR UPDATE TO authenticated
  USING (has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'librarian'));

CREATE POLICY "Admins and librarians can delete books" ON public.books
  FOR DELETE TO authenticated
  USING (has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'librarian'));

-- =====================================================
-- FIX 3: Tighten RLS policies on borrow_records table
-- =====================================================

-- Drop overly permissive policies
DROP POLICY IF EXISTS "Authenticated users can read borrow_records" ON public.borrow_records;
DROP POLICY IF EXISTS "Authenticated users can insert borrow_records" ON public.borrow_records;
DROP POLICY IF EXISTS "Authenticated users can update borrow_records" ON public.borrow_records;
DROP POLICY IF EXISTS "Authenticated users can delete borrow_records" ON public.borrow_records;

-- All staff can view borrow records
CREATE POLICY "All staff can view borrow_records" ON public.borrow_records
  FOR SELECT TO authenticated USING (true);

-- Only admins and librarians can manage borrow records
CREATE POLICY "Admins and librarians can insert borrow_records" ON public.borrow_records
  FOR INSERT TO authenticated
  WITH CHECK (has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'librarian'));

CREATE POLICY "Admins and librarians can update borrow_records" ON public.borrow_records
  FOR UPDATE TO authenticated
  USING (has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'librarian'));

CREATE POLICY "Admins and librarians can delete borrow_records" ON public.borrow_records
  FOR DELETE TO authenticated
  USING (has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'librarian'));

-- =====================================================
-- FIX 4: Add role checks to borrow_book RPC function
-- =====================================================

CREATE OR REPLACE FUNCTION public.borrow_book(p_book_id uuid, p_member_id uuid, p_due_date timestamp with time zone)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $$
DECLARE
  v_record_id UUID;
  v_available_copies INT;
  v_member_borrowed INT;
BEGIN
  -- CHECK AUTHORIZATION FIRST
  IF NOT (has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'librarian')) THEN
    RAISE EXCEPTION 'Access denied: admin or librarian role required';
  END IF;

  -- Validate inputs
  IF p_book_id IS NULL OR p_member_id IS NULL OR p_due_date IS NULL THEN
    RAISE EXCEPTION 'All parameters are required';
  END IF;

  -- Check book availability
  SELECT available_copies INTO v_available_copies
  FROM books WHERE id = p_book_id FOR UPDATE;
  
  IF v_available_copies IS NULL THEN
    RAISE EXCEPTION 'Book not found';
  END IF;
  
  IF v_available_copies < 1 THEN
    RAISE EXCEPTION 'No copies available for borrowing';
  END IF;
  
  -- Check member exists
  SELECT borrowed_books INTO v_member_borrowed
  FROM members WHERE id = p_member_id FOR UPDATE;
  
  IF v_member_borrowed IS NULL THEN
    RAISE EXCEPTION 'Member not found';
  END IF;

  -- All operations in a single transaction
  -- 1. Create borrow record
  INSERT INTO borrow_records (book_id, member_id, due_date, status)
  VALUES (p_book_id, p_member_id, p_due_date, 'active')
  RETURNING id INTO v_record_id;
  
  -- 2. Decrement book available copies
  UPDATE books 
  SET available_copies = available_copies - 1,
      updated_at = NOW()
  WHERE id = p_book_id;
  
  -- 3. Increment member borrowed books count
  UPDATE members 
  SET borrowed_books = borrowed_books + 1,
      updated_at = NOW()
  WHERE id = p_member_id;
  
  RETURN v_record_id;
END;
$$;

-- =====================================================
-- FIX 5: Add role checks to return_book RPC function
-- =====================================================

CREATE OR REPLACE FUNCTION public.return_book(p_record_id uuid, p_fine_amount numeric DEFAULT 0)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $$
DECLARE
  v_book_id UUID;
  v_member_id UUID;
  v_current_status TEXT;
BEGIN
  -- CHECK AUTHORIZATION FIRST
  IF NOT (has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'librarian')) THEN
    RAISE EXCEPTION 'Access denied: admin or librarian role required';
  END IF;

  -- Validate inputs
  IF p_record_id IS NULL THEN
    RAISE EXCEPTION 'Record ID is required';
  END IF;
  
  IF p_fine_amount < 0 THEN
    RAISE EXCEPTION 'Fine amount cannot be negative';
  END IF;

  -- Get the borrow record with lock
  SELECT book_id, member_id, status::TEXT INTO v_book_id, v_member_id, v_current_status
  FROM borrow_records WHERE id = p_record_id FOR UPDATE;
  
  IF v_book_id IS NULL THEN
    RAISE EXCEPTION 'Borrow record not found';
  END IF;
  
  IF v_current_status = 'returned' THEN
    RAISE EXCEPTION 'Book has already been returned';
  END IF;

  -- All operations in a single transaction
  -- 1. Update borrow record
  UPDATE borrow_records
  SET return_date = NOW(),
      status = 'returned',
      fine_amount = p_fine_amount,
      updated_at = NOW()
  WHERE id = p_record_id;
  
  -- 2. Increment book available copies
  UPDATE books 
  SET available_copies = available_copies + 1,
      updated_at = NOW()
  WHERE id = v_book_id;
  
  -- 3. Decrement member borrowed books count
  UPDATE members 
  SET borrowed_books = GREATEST(0, borrowed_books - 1),
      updated_at = NOW()
  WHERE id = v_member_id;
END;
$$;