-- Create enum types
CREATE TYPE public.book_status AS ENUM ('available', 'borrowed', 'reserved', 'maintenance');
CREATE TYPE public.member_status AS ENUM ('active', 'inactive', 'suspended');
CREATE TYPE public.membership_type AS ENUM ('basic', 'premium', 'student');
CREATE TYPE public.borrow_status AS ENUM ('active', 'returned', 'overdue');
CREATE TYPE public.activity_type AS ENUM ('book_added', 'book_updated', 'book_deleted', 'member_added', 'member_updated', 'member_deleted', 'book_borrowed', 'book_returned', 'fine_paid', 'login', 'logout');

-- Create profiles table for librarian users
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  full_name TEXT,
  avatar_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create books table
CREATE TABLE public.books (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  isbn TEXT UNIQUE NOT NULL,
  title TEXT NOT NULL,
  author TEXT NOT NULL,
  publisher TEXT,
  category TEXT NOT NULL,
  description TEXT,
  cover_image TEXT,
  total_copies INTEGER NOT NULL DEFAULT 1,
  available_copies INTEGER NOT NULL DEFAULT 1,
  location TEXT,
  status book_status NOT NULL DEFAULT 'available',
  published_year INTEGER,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create members table
CREATE TABLE public.members (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  member_id TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  phone TEXT,
  address TEXT,
  membership_type membership_type NOT NULL DEFAULT 'basic',
  status member_status NOT NULL DEFAULT 'active',
  join_date DATE NOT NULL DEFAULT CURRENT_DATE,
  expiry_date DATE,
  borrowed_books INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create borrow_records table
CREATE TABLE public.borrow_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  book_id UUID NOT NULL REFERENCES public.books(id) ON DELETE CASCADE,
  member_id UUID NOT NULL REFERENCES public.members(id) ON DELETE CASCADE,
  borrow_date TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  due_date TIMESTAMP WITH TIME ZONE NOT NULL,
  return_date TIMESTAMP WITH TIME ZONE,
  status borrow_status NOT NULL DEFAULT 'active',
  fine_amount DECIMAL(10, 2) DEFAULT 0,
  fine_paid BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create activity_logs table
CREATE TABLE public.activity_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  activity_type activity_type NOT NULL,
  description TEXT NOT NULL,
  metadata JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create notifications table
CREATE TABLE public.notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'info',
  read BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create library_settings table
CREATE TABLE public.library_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  setting_key TEXT UNIQUE NOT NULL,
  setting_value JSONB NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable Row Level Security on all tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.books ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.borrow_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.activity_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.library_settings ENABLE ROW LEVEL SECURITY;

-- RLS Policies for profiles
CREATE POLICY "Users can view their own profile" ON public.profiles
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile" ON public.profiles
  FOR UPDATE USING (auth.uid() = id);

-- RLS Policies for books (all authenticated users can read, modify)
CREATE POLICY "Authenticated users can read books" ON public.books
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Authenticated users can insert books" ON public.books
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Authenticated users can update books" ON public.books
  FOR UPDATE TO authenticated USING (true);

CREATE POLICY "Authenticated users can delete books" ON public.books
  FOR DELETE TO authenticated USING (true);

-- RLS Policies for members
CREATE POLICY "Authenticated users can read members" ON public.members
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Authenticated users can insert members" ON public.members
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Authenticated users can update members" ON public.members
  FOR UPDATE TO authenticated USING (true);

CREATE POLICY "Authenticated users can delete members" ON public.members
  FOR DELETE TO authenticated USING (true);

-- RLS Policies for borrow_records
CREATE POLICY "Authenticated users can read borrow_records" ON public.borrow_records
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Authenticated users can insert borrow_records" ON public.borrow_records
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Authenticated users can update borrow_records" ON public.borrow_records
  FOR UPDATE TO authenticated USING (true);

CREATE POLICY "Authenticated users can delete borrow_records" ON public.borrow_records
  FOR DELETE TO authenticated USING (true);

-- RLS Policies for activity_logs
CREATE POLICY "Authenticated users can read activity_logs" ON public.activity_logs
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Authenticated users can insert activity_logs" ON public.activity_logs
  FOR INSERT TO authenticated WITH CHECK (true);

-- RLS Policies for notifications
CREATE POLICY "Users can read their own notifications" ON public.notifications
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own notifications" ON public.notifications
  FOR UPDATE TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "System can insert notifications" ON public.notifications
  FOR INSERT TO authenticated WITH CHECK (true);

-- RLS Policies for library_settings
CREATE POLICY "Authenticated users can read settings" ON public.library_settings
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Authenticated users can modify settings" ON public.library_settings
  FOR ALL TO authenticated USING (true);

-- Create function to handle profile creation on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data ->> 'full_name', NEW.email)
  );
  RETURN NEW;
END;
$$;

-- Create trigger for new user signup
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;

-- Create triggers for updated_at
CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_books_updated_at
  BEFORE UPDATE ON public.books
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_members_updated_at
  BEFORE UPDATE ON public.members
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_borrow_records_updated_at
  BEFORE UPDATE ON public.borrow_records
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default library settings
INSERT INTO public.library_settings (setting_key, setting_value) VALUES
  ('loan_period', '{"days": 14}'::jsonb),
  ('fine_per_day', '{"amount": 0.50}'::jsonb),
  ('max_fine', '{"amount": 25.00}'::jsonb),
  ('max_books_per_member', '{"basic": 3, "premium": 10, "student": 5}'::jsonb);