-- 1. Create atomic borrow_book function with transaction protection
CREATE OR REPLACE FUNCTION public.borrow_book(
  p_book_id UUID,
  p_member_id UUID,
  p_due_date TIMESTAMP WITH TIME ZONE
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_record_id UUID;
  v_available_copies INT;
  v_member_borrowed INT;
BEGIN
  -- Validate inputs
  IF p_book_id IS NULL OR p_member_id IS NULL OR p_due_date IS NULL THEN
    RAISE EXCEPTION 'All parameters are required';
  END IF;

  -- Check book availability
  SELECT available_copies INTO v_available_copies
  FROM books WHERE id = p_book_id FOR UPDATE;
  
  IF v_available_copies IS NULL THEN
    RAISE EXCEPTION 'Book not found';
  END IF;
  
  IF v_available_copies < 1 THEN
    RAISE EXCEPTION 'No copies available for borrowing';
  END IF;
  
  -- Check member exists
  SELECT borrowed_books INTO v_member_borrowed
  FROM members WHERE id = p_member_id FOR UPDATE;
  
  IF v_member_borrowed IS NULL THEN
    RAISE EXCEPTION 'Member not found';
  END IF;

  -- All operations in a single transaction
  -- 1. Create borrow record
  INSERT INTO borrow_records (book_id, member_id, due_date, status)
  VALUES (p_book_id, p_member_id, p_due_date, 'active')
  RETURNING id INTO v_record_id;
  
  -- 2. Decrement book available copies
  UPDATE books 
  SET available_copies = available_copies - 1,
      updated_at = NOW()
  WHERE id = p_book_id;
  
  -- 3. Increment member borrowed books count
  UPDATE members 
  SET borrowed_books = borrowed_books + 1,
      updated_at = NOW()
  WHERE id = p_member_id;
  
  RETURN v_record_id;
END;
$$;

-- 2. Create atomic return_book function with transaction protection
CREATE OR REPLACE FUNCTION public.return_book(
  p_record_id UUID,
  p_fine_amount NUMERIC DEFAULT 0
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_book_id UUID;
  v_member_id UUID;
  v_current_status TEXT;
BEGIN
  -- Validate inputs
  IF p_record_id IS NULL THEN
    RAISE EXCEPTION 'Record ID is required';
  END IF;
  
  IF p_fine_amount < 0 THEN
    RAISE EXCEPTION 'Fine amount cannot be negative';
  END IF;

  -- Get the borrow record with lock
  SELECT book_id, member_id, status::TEXT INTO v_book_id, v_member_id, v_current_status
  FROM borrow_records WHERE id = p_record_id FOR UPDATE;
  
  IF v_book_id IS NULL THEN
    RAISE EXCEPTION 'Borrow record not found';
  END IF;
  
  IF v_current_status = 'returned' THEN
    RAISE EXCEPTION 'Book has already been returned';
  END IF;

  -- All operations in a single transaction
  -- 1. Update borrow record
  UPDATE borrow_records
  SET return_date = NOW(),
      status = 'returned',
      fine_amount = p_fine_amount,
      updated_at = NOW()
  WHERE id = p_record_id;
  
  -- 2. Increment book available copies
  UPDATE books 
  SET available_copies = available_copies + 1,
      updated_at = NOW()
  WHERE id = v_book_id;
  
  -- 3. Decrement member borrowed books count
  UPDATE members 
  SET borrowed_books = GREATEST(0, borrowed_books - 1),
      updated_at = NOW()
  WHERE id = v_member_id;
END;
$$;

-- 3. Update handle_new_user function with input validation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_full_name TEXT;
  v_email TEXT;
BEGIN
  -- Validate and sanitize email (max 255 chars)
  v_email := COALESCE(NEW.email, '');
  IF LENGTH(v_email) > 255 THEN
    v_email := SUBSTRING(v_email, 1, 255);
  END IF;
  
  -- Validate and sanitize full_name (max 100 chars)
  v_full_name := COALESCE(NEW.raw_user_meta_data ->> 'full_name', v_email);
  IF LENGTH(v_full_name) > 100 THEN
    v_full_name := SUBSTRING(v_full_name, 1, 100);
  END IF;
  
  -- Remove any potentially dangerous characters (basic sanitization)
  v_full_name := REGEXP_REPLACE(v_full_name, '[<>"\x00-\x1F]', '', 'g');
  
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (NEW.id, v_email, v_full_name);
  
  RETURN NEW;
END;
$$;

-- 4. Add CHECK constraints on profiles table for additional validation
DO $$
BEGIN
  -- Add length constraint on full_name if not exists
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.check_constraints 
    WHERE constraint_name = 'profiles_full_name_length'
  ) THEN
    ALTER TABLE public.profiles ADD CONSTRAINT profiles_full_name_length 
      CHECK (LENGTH(full_name) <= 100 OR full_name IS NULL);
  END IF;
  
  -- Add length constraint on email if not exists
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.check_constraints 
    WHERE constraint_name = 'profiles_email_length'
  ) THEN
    ALTER TABLE public.profiles ADD CONSTRAINT profiles_email_length 
      CHECK (LENGTH(email) <= 255);
  END IF;
END $$;