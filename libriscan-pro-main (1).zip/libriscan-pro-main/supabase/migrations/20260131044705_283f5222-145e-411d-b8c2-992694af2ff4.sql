-- Fix remaining overly permissive policy
DROP POLICY IF EXISTS "System can insert notifications" ON notifications;