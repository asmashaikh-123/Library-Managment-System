/**
 * Utility functions for sanitizing error messages before displaying to users.
 * This prevents information leakage about database structure, internal operations, etc.
 */

/**
 * Sanitizes an error message to prevent information leakage.
 * Logs the full error for debugging while returning a safe user-facing message.
 */
export function sanitizeErrorMessage(error: Error): string {
  // Only log full error in development mode to prevent information leakage in production
  if (import.meta.env.DEV) {
    console.error('Operation failed:', error);
  }
  
  const message = error.message?.toLowerCase() || '';
  
  // Handle duplicate/unique constraint violations
  if (message.includes('duplicate') || message.includes('unique constraint')) {
    return 'This record already exists';
  }
  
  // Handle permission errors
  if (message.includes('permission denied') || message.includes('not authorized')) {
    return 'Access denied';
  }
  
  // Handle constraint violations
  if (message.includes('constraint') || message.includes('violates')) {
    return 'Invalid data provided';
  }
  
  // Handle foreign key errors
  if (message.includes('foreign key')) {
    return 'Referenced record not found';
  }
  
  // Handle not found errors
  if (message.includes('not found')) {
    return 'Record not found';
  }
  
  // Handle network errors
  if (message.includes('network') || message.includes('fetch') || message.includes('connection')) {
    return 'Network error. Please check your connection and try again';
  }
  
  // Handle rate limiting
  if (message.includes('rate limit') || message.includes('too many requests')) {
    return 'Too many requests. Please wait and try again';
  }
  
  // Handle timeout errors
  if (message.includes('timeout')) {
    return 'Request timed out. Please try again';
  }
  
  // Handle authentication errors - keep some specific ones for user feedback
  if (message.includes('invalid login credentials')) {
    return 'Invalid email or password';
  }
  
  if (message.includes('already registered')) {
    return 'This email is already registered';
  }
  
  if (message.includes('email not confirmed')) {
    return 'Please confirm your email before signing in';
  }
  
  // Handle borrow-specific errors (from our RPC functions)
  if (message.includes('no copies available')) {
    return 'No copies available for borrowing';
  }
  
  if (message.includes('already been returned')) {
    return 'This book has already been returned';
  }
  
  if (message.includes('member not found')) {
    return 'Member not found';
  }
  
  if (message.includes('book not found')) {
    return 'Book not found';
  }
  
  // Default safe message
  return 'An error occurred. Please try again';
}
