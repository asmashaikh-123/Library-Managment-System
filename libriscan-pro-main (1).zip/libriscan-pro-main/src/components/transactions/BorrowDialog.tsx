import { useState } from 'react';
import { useBooks } from '@/hooks/useBooks';
import { useMembers } from '@/hooks/useMembers';
import { useBorrowRecords } from '@/hooks/useBorrowRecords';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from '@/hooks/use-toast';
import { Loader2 } from 'lucide-react';

interface BorrowDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  preselectedBookId?: string;
}

export function BorrowDialog({ open, onOpenChange, preselectedBookId }: BorrowDialogProps) {
  const { books } = useBooks();
  const { members } = useMembers();
  const { borrowBook, isBorrowing } = useBorrowRecords();
  const [selectedBook, setSelectedBook] = useState(preselectedBookId || '');
  const [selectedMember, setSelectedMember] = useState('');

  const availableBooks = books.filter(b => b.available_copies > 0);
  const activeMembers = members.filter(m => m.status === 'active');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedBook || !selectedMember) {
      toast({
        title: 'Error',
        description: 'Please select both a book and a member',
        variant: 'destructive',
      });
      return;
    }

    const book = books.find(b => b.id === selectedBook);
    const member = members.find(m => m.id === selectedMember);
    const dueDate = new Date();
    dueDate.setDate(dueDate.getDate() + 14);

    borrowBook({ bookId: selectedBook, memberId: selectedMember, dueDate });
    
    toast({
      title: 'Book Borrowed',
      description: `Successfully borrowed "${book?.title}" to ${member?.name}`,
    });
    onOpenChange(false);
    setSelectedBook('');
    setSelectedMember('');
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Borrow Book</DialogTitle>
          <DialogDescription>
            Select a book and member to create a new borrow record.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label>Select Book</Label>
              <Select value={selectedBook} onValueChange={setSelectedBook}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a book..." />
                </SelectTrigger>
                <SelectContent>
                  {availableBooks.map((book) => (
                    <SelectItem key={book.id} value={book.id}>
                      {book.title} ({book.available_copies} available)
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Select Member</Label>
              <Select value={selectedMember} onValueChange={setSelectedMember}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a member..." />
                </SelectTrigger>
                <SelectContent>
                  {activeMembers.map((member) => (
                    <SelectItem key={member.id} value={member.id}>
                      {member.name} ({member.member_id})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="rounded-lg bg-secondary/50 p-4 text-sm">
              <p className="font-medium text-foreground">Loan Period: 14 days</p>
              <p className="text-muted-foreground">
                Due date will be automatically calculated from today.
              </p>
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={isBorrowing}>
              {isBorrowing && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Confirm Borrow
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
