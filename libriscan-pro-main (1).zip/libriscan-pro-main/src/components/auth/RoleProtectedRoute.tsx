import { Navigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';

type AppRole = 'admin' | 'librarian' | 'staff';

interface RoleProtectedRouteProps {
  children: React.ReactNode;
  allowedRoles: AppRole[];
  fallbackPath?: string;
}

/**
 * A wrapper component that restricts access to routes based on user role.
 * If the user doesn't have one of the allowed roles, they are redirected.
 * 
 * Note: This is defense-in-depth only. Backend RLS policies are the primary security control.
 */
export function RoleProtectedRoute({ 
  children, 
  allowedRoles,
  fallbackPath = '/'
}: RoleProtectedRouteProps) {
  const { user, isLoading } = useAuth();
  
  // While loading, show nothing to prevent flicker
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }
  
  // If no user or user role is not in allowed roles, redirect
  if (!user || !allowedRoles.includes(user.role as AppRole)) {
    return <Navigate to={fallbackPath} replace />;
  }
  
  return <>{children}</>;
}

/**
 * Hook to check if the current user has one of the specified roles.
 * Useful for conditional rendering of UI elements.
 */
export function useHasRole(allowedRoles: AppRole[]): boolean {
  const { user } = useAuth();
  
  if (!user) return false;
  return allowedRoles.includes(user.role as AppRole);
}
