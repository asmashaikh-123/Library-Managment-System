import { useState, useEffect } from 'react';
import { Book, BookInsert } from '@/hooks/useBooks';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Loader2 } from 'lucide-react';

interface BookDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  book?: Book | null;
  onSave: (book: Omit<BookInsert, 'id'>) => void;
  isLoading?: boolean;
}

const categories = ['Programming', 'Fiction', 'Science', 'History', 'Biography', 'Business', 'Self-Help', 'Other'];

export function BookDialog({ open, onOpenChange, book, onSave, isLoading }: BookDialogProps) {
  const [formData, setFormData] = useState({
    isbn: '',
    title: '',
    author: '',
    category: 'Programming',
    published_year: new Date().getFullYear(),
    total_copies: 1,
    available_copies: 1,
    location: '',
    description: '',
    publisher: '',
  });

  useEffect(() => {
    if (book) {
      setFormData({
        isbn: book.isbn,
        title: book.title,
        author: book.author,
        category: book.category,
        published_year: book.published_year || new Date().getFullYear(),
        total_copies: book.total_copies,
        available_copies: book.available_copies,
        location: book.location || '',
        description: book.description || '',
        publisher: book.publisher || '',
      });
    } else {
      setFormData({
        isbn: '',
        title: '',
        author: '',
        category: 'Programming',
        published_year: new Date().getFullYear(),
        total_copies: 1,
        available_copies: 1,
        location: '',
        description: '',
        publisher: '',
      });
    }
  }, [book, open]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      isbn: formData.isbn,
      title: formData.title,
      author: formData.author,
      category: formData.category,
      published_year: formData.published_year,
      total_copies: formData.total_copies,
      available_copies: formData.available_copies,
      location: formData.location || null,
      description: formData.description || null,
      publisher: formData.publisher || null,
      cover_image: null,
      status: 'available',
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>{book ? 'Edit Book' : 'Add New Book'}</DialogTitle>
          <DialogDescription>
            {book ? 'Update the book information below.' : 'Fill in the details to add a new book to the library.'}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="isbn">ISBN</Label>
                <Input
                  id="isbn"
                  value={formData.isbn}
                  onChange={(e) => setFormData({ ...formData, isbn: e.target.value })}
                  placeholder="978-0-00-000000-0"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="location">Location</Label>
                <Input
                  id="location"
                  value={formData.location}
                  onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  placeholder="A-12"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="title">Title</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                placeholder="Book title"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="author">Author</Label>
              <Input
                id="author"
                value={formData.author}
                onChange={(e) => setFormData({ ...formData, author: e.target.value })}
                placeholder="Author name"
                required
              />
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="category">Category</Label>
                <Select
                  value={formData.category}
                  onValueChange={(value) => setFormData({ ...formData, category: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((cat) => (
                      <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="year">Published Year</Label>
                <Input
                  id="year"
                  type="number"
                  value={formData.published_year}
                  onChange={(e) => setFormData({ ...formData, published_year: parseInt(e.target.value) })}
                  min={1000}
                  max={new Date().getFullYear()}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="copies">Total Copies</Label>
                <Input
                  id="copies"
                  type="number"
                  value={formData.total_copies}
                  onChange={(e) => {
                    const total = parseInt(e.target.value);
                    setFormData({ 
                      ...formData, 
                      total_copies: total,
                      available_copies: book ? formData.available_copies : total
                    });
                  }}
                  min={1}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Brief description of the book"
                rows={3}
              />
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {book ? 'Save Changes' : 'Add Book'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
