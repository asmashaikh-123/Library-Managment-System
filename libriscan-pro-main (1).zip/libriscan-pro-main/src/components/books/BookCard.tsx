import { Book } from '@/hooks/useBooks';
import { MapPin, Copy, Edit2, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

interface BookCardProps {
  book: Book;
  onEdit?: (book: Book) => void;
  onDelete?: (book: Book) => void;
  onSelect?: (book: Book) => void;
}

export function BookCard({ book, onEdit, onDelete, onSelect }: BookCardProps) {
  const isAvailable = book.available_copies > 0;

  return (
    <div 
      className="group rounded-xl border border-border bg-card p-5 shadow-soft transition-all duration-200 hover:shadow-medium animate-fade-in cursor-pointer"
      onClick={() => onSelect?.(book)}
    >
      <div className="flex gap-4">
        {/* Book Cover Placeholder */}
        <div className="flex h-32 w-24 flex-shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-primary/20 to-primary/5 text-primary">
          <span className="text-3xl font-bold">{book.title[0]}</span>
        </div>

        <div className="flex flex-1 flex-col">
          <div className="flex items-start justify-between">
            <div>
              <h3 className="font-semibold text-foreground line-clamp-1">{book.title}</h3>
              <p className="text-sm text-muted-foreground">{book.author}</p>
            </div>
            <Badge variant={isAvailable ? 'default' : 'destructive'} className="ml-2">
              {isAvailable ? 'Available' : 'Unavailable'}
            </Badge>
          </div>

          <p className="mt-2 text-xs text-muted-foreground line-clamp-2">{book.description}</p>

          <div className="mt-auto flex items-center gap-4 pt-3 text-sm text-muted-foreground">
            <span className="flex items-center gap-1">
              <MapPin className="h-3.5 w-3.5" />
              {book.location || 'N/A'}
            </span>
            <span className="flex items-center gap-1">
              <Copy className="h-3.5 w-3.5" />
              {book.available_copies}/{book.total_copies}
            </span>
            <span className="text-xs">{book.category}</span>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="mt-4 flex justify-end gap-2 border-t border-border pt-4 opacity-0 transition-opacity group-hover:opacity-100">
        <Button
          variant="ghost"
          size="sm"
          onClick={(e) => {
            e.stopPropagation();
            onEdit?.(book);
          }}
        >
          <Edit2 className="mr-1.5 h-4 w-4" />
          Edit
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className="text-destructive hover:bg-destructive/10 hover:text-destructive"
          onClick={(e) => {
            e.stopPropagation();
            onDelete?.(book);
          }}
        >
          <Trash2 className="mr-1.5 h-4 w-4" />
          Delete
        </Button>
      </div>
    </div>
  );
}
