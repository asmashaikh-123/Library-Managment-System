import { ArrowDownLeft, ArrowUpRight, Loader2 } from 'lucide-react';
import { useBorrowRecords, BorrowRecordWithDetails } from '@/hooks/useBorrowRecords';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';

export function RecentActivity() {
  const { borrowRecords, isLoading } = useBorrowRecords();
  
  const recentRecords = [...borrowRecords]
    .sort((a, b) => new Date(b.borrow_date).getTime() - new Date(a.borrow_date).getTime())
    .slice(0, 5);

  if (isLoading) {
    return (
      <div className="rounded-xl border border-border bg-card p-6 shadow-soft animate-slide-up flex items-center justify-center min-h-[200px]">
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="rounded-xl border border-border bg-card p-6 shadow-soft animate-slide-up">
      <h3 className="text-lg font-semibold text-foreground">Recent Activity</h3>
      <p className="text-sm text-muted-foreground">Latest transactions in the library</p>
      
      <div className="mt-6 space-y-4">
        {recentRecords.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <p>No recent activity</p>
          </div>
        ) : (
          recentRecords.map((record) => (
            <div
              key={record.id}
              className="flex items-center gap-4 rounded-lg bg-secondary/50 p-4 transition-colors hover:bg-secondary"
            >
              <div className={cn(
                'flex h-10 w-10 items-center justify-center rounded-full',
                record.status === 'returned' ? 'bg-success/10 text-success' : 'bg-primary/10 text-primary'
              )}>
                {record.status === 'returned' ? (
                  <ArrowDownLeft className="h-5 w-5" />
                ) : (
                  <ArrowUpRight className="h-5 w-5" />
                )}
              </div>
              <div className="flex-1">
                <p className="font-medium text-foreground">{record.books?.title || 'Unknown Book'}</p>
                <p className="text-sm text-muted-foreground">
                  {record.status === 'returned' ? 'Returned by' : 'Borrowed by'} {record.members?.name || 'Unknown'}
                </p>
              </div>
              <div className="text-right">
                <p className="text-sm font-medium text-foreground">
                  {format(new Date(record.status === 'returned' && record.return_date ? record.return_date : record.borrow_date), 'MMM d, yyyy')}
                </p>
                <p className={cn(
                  'text-xs font-medium capitalize',
                  record.status === 'returned' && 'text-success',
                  record.status === 'active' && 'text-primary',
                  record.status === 'overdue' && 'text-destructive'
                )}>
                  {record.status}
                </p>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
