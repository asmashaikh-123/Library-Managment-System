import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, 
  BookOpen, 
  Users, 
  ArrowRightLeft, 
  QrCode,
  Settings,
  Library,
  BarChart3,
  ClipboardList,
  BookMarked,
  LogOut
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

type AppRole = 'admin' | 'librarian' | 'staff';

interface NavItem {
  icon: typeof LayoutDashboard;
  label: string;
  path: string;
  allowedRoles?: AppRole[]; // If undefined, all roles have access
}

const navItems: NavItem[] = [
  { icon: LayoutDashboard, label: 'Dashboard', path: '/' },
  { icon: BookOpen, label: 'Books', path: '/books' },
  { icon: Users, label: 'Members', path: '/members' },
  { icon: BookMarked, label: 'Issue / Return', path: '/issue-return' },
  { icon: ArrowRightLeft, label: 'Transactions', path: '/transactions' },
  { icon: QrCode, label: 'QR Scanner', path: '/scanner' },
  { icon: BarChart3, label: 'Analytics', path: '/analytics' },
  { icon: ClipboardList, label: 'Activity Logs', path: '/activity-logs' },
  { icon: Settings, label: 'Settings', path: '/settings', allowedRoles: ['admin'] },
];

export function Sidebar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  // Filter nav items based on user role
  const filteredNavItems = navItems.filter(item => {
    // If no role restriction, show to everyone
    if (!item.allowedRoles) return true;
    // Check if user has one of the allowed roles
    return item.allowedRoles.includes(user?.role as AppRole);
  });

  return (
    <aside className="fixed left-0 top-0 z-40 h-screen w-64 border-r border-border bg-sidebar">
      <div className="flex h-full flex-col">
        {/* Logo */}
        <div className="flex h-16 items-center gap-3 border-b border-border px-6">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-primary-foreground">
            <Library className="h-5 w-5" />
          </div>
          <div>
            <h1 className="text-lg font-semibold text-sidebar-foreground">LibraryHub</h1>
            <p className="text-xs text-muted-foreground">Management System</p>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 space-y-1 p-4 overflow-y-auto">
          {filteredNavItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                cn(
                  'flex items-center gap-3 rounded-lg px-4 py-3 text-sm font-medium transition-all duration-200',
                  isActive
                    ? 'bg-primary text-primary-foreground shadow-soft'
                    : 'text-muted-foreground hover:bg-sidebar-accent hover:text-sidebar-foreground'
                )
              }
            >
              <item.icon className="h-5 w-5" />
              {item.label}
            </NavLink>
          ))}
        </nav>

        {/* User & Logout */}
        <div className="border-t border-border p-4 space-y-3">
          {user && (
            <div className="rounded-lg bg-secondary/50 p-3">
              <p className="text-sm font-medium text-sidebar-foreground">{user.name}</p>
              <p className="text-xs text-muted-foreground capitalize">{user.role}</p>
            </div>
          )}
          <Button
            variant="ghost"
            className="w-full justify-start gap-2 text-muted-foreground hover:text-destructive hover:bg-destructive/10"
            onClick={handleLogout}
          >
            <LogOut className="h-4 w-4" />
            Sign Out
          </Button>
        </div>
      </div>
    </aside>
  );
}
