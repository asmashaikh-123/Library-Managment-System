import { useEffect, useRef, useState, useCallback } from 'react';
import { Html5Qrcode } from 'html5-qrcode';
import { Camera, CameraOff, RotateCcw, Keyboard } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';

interface QRScannerProps {
  onScan: (result: string) => void;
  className?: string;
}

export function QRScanner({ onScan, className }: QRScannerProps) {
  const [isScanning, setIsScanning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showManualInput, setShowManualInput] = useState(false);
  const [manualIsbn, setManualIsbn] = useState('');
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const isScanningRef = useRef(false); // Track actual scanner state
  const containerId = 'qr-reader';

  const stopScanning = useCallback(async () => {
    // Only try to stop if we know scanner is actually running
    if (scannerRef.current && isScanningRef.current) {
      try {
        await scannerRef.current.stop();
      } catch (err) {
        // Ignore stop errors - scanner might already be stopped
        console.log('Scanner stop handled:', err);
      }
    }
    isScanningRef.current = false;
    setIsScanning(false);
  }, []);

  const startScanning = async () => {
    setError(null);
    
    try {
      // Stop any existing scanner first
      await stopScanning();
      
      // Clear the container before creating new scanner
      const container = document.getElementById(containerId);
      if (container) {
        container.innerHTML = '';
      }
      
      // Create new scanner instance
      scannerRef.current = new Html5Qrcode(containerId);

      await scannerRef.current.start(
        { facingMode: 'environment' },
        {
          fps: 10,
          qrbox: { width: 250, height: 250 },
        },
        (decodedText) => {
          onScan(decodedText);
          stopScanning();
        },
        () => {
          // QR code not detected, continue scanning
        }
      );
      
      isScanningRef.current = true;
      setIsScanning(true);
    } catch (err) {
      console.error('Failed to start scanner:', err);
      isScanningRef.current = false;
      setIsScanning(false);
      
      // Provide helpful error message based on error type
      const errorMessage = err instanceof Error ? err.message : String(err);
      if (errorMessage.includes('NotReadableError') || errorMessage.includes('video source')) {
        setError('Camera is in use by another app or not available. Try closing other apps using the camera, or use manual ISBN entry below.');
      } else if (errorMessage.includes('NotAllowedError') || errorMessage.includes('Permission')) {
        setError('Camera permission denied. Please allow camera access in your browser settings, or use manual ISBN entry below.');
      } else if (errorMessage.includes('NotFoundError')) {
        setError('No camera found on this device. Please use manual ISBN entry below.');
      } else {
        setError('Failed to access camera. Please use manual ISBN entry below.');
      }
      setShowManualInput(true);
    }
  };

  const handleManualSubmit = () => {
    if (manualIsbn.trim()) {
      onScan(manualIsbn.trim());
      setManualIsbn('');
    }
  };

  useEffect(() => {
    return () => {
      // Cleanup on unmount
      if (scannerRef.current && isScanningRef.current) {
        scannerRef.current.stop().catch(() => {
          // Ignore cleanup errors
        });
      }
    };
  }, []);

  return (
    <div className={cn('flex flex-col items-center', className)}>
      <div className="relative w-full max-w-md overflow-hidden rounded-2xl bg-secondary/50">
        {/* Scanner Container */}
        <div
          id={containerId}
          className={cn(
            'aspect-square w-full',
            !isScanning && 'flex items-center justify-center bg-muted'
          )}
        >
          {!isScanning && (
            <div className="text-center p-8">
              <div className="mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-full bg-primary/10">
                <Camera className="h-10 w-10 text-primary" />
              </div>
              <p className="text-lg font-medium text-foreground">Ready to Scan</p>
              <p className="mt-1 text-sm text-muted-foreground">
                Click the button below to start scanning
              </p>
            </div>
          )}
        </div>

        {/* Scanning Overlay */}
        {isScanning && (
          <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
            <div className="h-64 w-64 rounded-2xl border-2 border-primary shadow-glow" />
          </div>
        )}
      </div>

      {/* Error Message */}
      {error && (
        <div className="mt-4 rounded-lg bg-destructive/10 px-4 py-3 text-sm text-destructive">
          {error}
        </div>
      )}

      {/* Controls */}
      <div className="mt-6 flex flex-wrap gap-3 justify-center">
        {!isScanning ? (
          <>
            <Button onClick={startScanning} size="lg" className="gap-2">
              <Camera className="h-5 w-5" />
              Start Scanner
            </Button>
            <Button 
              onClick={() => setShowManualInput(!showManualInput)} 
              variant="outline" 
              size="lg" 
              className="gap-2"
            >
              <Keyboard className="h-5 w-5" />
              Manual Entry
            </Button>
          </>
        ) : (
          <>
            <Button onClick={stopScanning} variant="outline" size="lg" className="gap-2">
              <CameraOff className="h-5 w-5" />
              Stop Scanner
            </Button>
            <Button 
              onClick={() => {
                stopScanning();
                setTimeout(startScanning, 300);
              }} 
              variant="secondary" 
              size="lg" 
              className="gap-2"
            >
              <RotateCcw className="h-5 w-5" />
              Restart
            </Button>
          </>
        )}
      </div>

      {/* Manual ISBN Entry */}
      {showManualInput && (
        <div className="mt-6 w-full max-w-md space-y-3">
          <div className="flex gap-2">
            <Input
              placeholder="Enter ISBN (e.g., 978-0-13-468599-1)"
              value={manualIsbn}
              onChange={(e) => setManualIsbn(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  handleManualSubmit();
                }
              }}
            />
            <Button onClick={handleManualSubmit} disabled={!manualIsbn.trim()}>
              Search
            </Button>
          </div>
          <p className="text-xs text-muted-foreground text-center">
            Enter the book's ISBN to look it up manually
          </p>
        </div>
      )}
    </div>
  );
}
