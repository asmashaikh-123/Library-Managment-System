import { Member } from '@/hooks/useMembers';
import { Mail, Phone, BookOpen, Edit2, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

interface MemberCardProps {
  member: Member;
  onEdit?: (member: Member) => void;
  onDelete?: (member: Member) => void;
}

const statusStyles = {
  active: 'bg-success/10 text-success border-success/20',
  suspended: 'bg-destructive/10 text-destructive border-destructive/20',
  inactive: 'bg-muted text-muted-foreground border-muted-foreground/20',
};

const membershipStyles = {
  basic: 'bg-secondary text-secondary-foreground',
  premium: 'bg-accent text-accent-foreground',
  student: 'bg-primary/10 text-primary',
};

export function MemberCard({ member, onEdit, onDelete }: MemberCardProps) {
  return (
    <div className="group rounded-xl border border-border bg-card p-5 shadow-soft transition-all duration-200 hover:shadow-medium animate-fade-in">
      <div className="flex items-start gap-4">
        {/* Avatar */}
        <div className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground text-lg font-semibold">
          {member.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
        </div>

        <div className="flex-1">
          <div className="flex items-start justify-between">
            <div>
              <h3 className="font-semibold text-foreground">{member.name}</h3>
              <p className="text-sm text-muted-foreground">{member.member_id}</p>
            </div>
            <div className="flex gap-2">
              <Badge className={cn('capitalize', membershipStyles[member.membership_type])}>
                {member.membership_type}
              </Badge>
              <Badge variant="outline" className={cn('capitalize', statusStyles[member.status])}>
                {member.status}
              </Badge>
            </div>
          </div>

          <div className="mt-3 grid grid-cols-2 gap-2 text-sm text-muted-foreground">
            <span className="flex items-center gap-1.5">
              <Mail className="h-3.5 w-3.5" />
              {member.email}
            </span>
            <span className="flex items-center gap-1.5">
              <Phone className="h-3.5 w-3.5" />
              {member.phone || 'N/A'}
            </span>
          </div>

          <div className="mt-3 flex items-center gap-4 text-sm">
            <span className="flex items-center gap-1.5 text-muted-foreground">
              <BookOpen className="h-3.5 w-3.5" />
              {member.borrowed_books} books borrowed
            </span>
            <span className="text-muted-foreground">
              Member since {new Date(member.join_date).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}
            </span>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="mt-4 flex justify-end gap-2 border-t border-border pt-4 opacity-0 transition-opacity group-hover:opacity-100">
        <Button variant="ghost" size="sm" onClick={() => onEdit?.(member)}>
          <Edit2 className="mr-1.5 h-4 w-4" />
          Edit
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className="text-destructive hover:bg-destructive/10 hover:text-destructive"
          onClick={() => onDelete?.(member)}
        >
          <Trash2 className="mr-1.5 h-4 w-4" />
          Delete
        </Button>
      </div>
    </div>
  );
}
