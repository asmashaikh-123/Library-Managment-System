import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { sanitizeErrorMessage } from '@/lib/errorUtils';

export interface BorrowRecord {
  id: string;
  book_id: string;
  member_id: string;
  borrow_date: string;
  due_date: string;
  return_date: string | null;
  status: 'active' | 'returned' | 'overdue';
  fine_amount: number;
  fine_paid: boolean;
  created_at: string;
  updated_at: string;
  // Joined fields (using plural names for compatibility)
  books?: {
    id: string;
    title: string;
    isbn: string;
    author: string;
  };
  members?: {
    id: string;
    name: string;
    member_id: string;
    email: string;
  };
}

export type BorrowRecordWithDetails = BorrowRecord;

export function useBorrowRecords() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: borrowRecords = [], isLoading, error } = useQuery({
    queryKey: ['borrow_records'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('borrow_records')
        .select(`
          *,
          books(id, title, isbn, author),
          members(id, name, member_id, email)
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data as BorrowRecord[];
    },
  });

  const borrowBookMutation = useMutation({
    mutationFn: async ({ bookId, memberId, dueDate }: { bookId: string; memberId: string; dueDate?: Date }) => {
      const actualDueDate = dueDate || new Date(Date.now() + 14 * 24 * 60 * 60 * 1000); // Default 14 days
      
      // Use atomic RPC function for transaction safety
      const { data, error } = await supabase.rpc('borrow_book', {
        p_book_id: bookId,
        p_member_id: memberId,
        p_due_date: actualDueDate.toISOString(),
      });

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['borrow_records'] });
      queryClient.invalidateQueries({ queryKey: ['books'] });
      queryClient.invalidateQueries({ queryKey: ['members'] });
      queryClient.invalidateQueries({ queryKey: ['library_stats'] });
      toast({ title: 'Book borrowed successfully' });
    },
    onError: (error: Error) => {
      toast({ 
        title: 'Failed to borrow book', 
        description: sanitizeErrorMessage(error), 
        variant: 'destructive' 
      });
    },
  });

  const returnBookMutation = useMutation({
    mutationFn: async ({ recordId, fineAmount = 0 }: { recordId: string; fineAmount?: number }) => {
      // Use atomic RPC function for transaction safety
      const { error } = await supabase.rpc('return_book', {
        p_record_id: recordId,
        p_fine_amount: fineAmount,
      });

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['borrow_records'] });
      queryClient.invalidateQueries({ queryKey: ['books'] });
      queryClient.invalidateQueries({ queryKey: ['members'] });
      queryClient.invalidateQueries({ queryKey: ['library_stats'] });
      toast({ title: 'Book returned successfully' });
    },
    onError: (error: Error) => {
      toast({ 
        title: 'Failed to return book', 
        description: sanitizeErrorMessage(error), 
        variant: 'destructive' 
      });
    },
  });

  const payFineMutation = useMutation({
    mutationFn: async (recordId: string) => {
      const { error } = await supabase
        .from('borrow_records')
        .update({ fine_paid: true })
        .eq('id', recordId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['borrow_records'] });
      queryClient.invalidateQueries({ queryKey: ['library_stats'] });
      toast({ title: 'Fine paid successfully' });
    },
    onError: (error: Error) => {
      toast({ 
        title: 'Failed to pay fine', 
        description: sanitizeErrorMessage(error), 
        variant: 'destructive' 
      });
    },
  });

  return {
    borrowRecords,
    isLoading,
    error,
    borrowBook: borrowBookMutation.mutate,
    returnBook: returnBookMutation.mutate,
    payFine: payFineMutation.mutate,
    isBorrowing: borrowBookMutation.isPending,
    isReturning: returnBookMutation.isPending,
    isPayingFine: payFineMutation.isPending,
  };
}
