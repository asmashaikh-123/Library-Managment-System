import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Json } from '@/integrations/supabase/types';

export type ActivityType = 'book_added' | 'book_updated' | 'book_deleted' | 'member_added' | 'member_updated' | 'member_deleted' | 'book_borrowed' | 'book_returned' | 'fine_paid' | 'login' | 'logout';

export interface ActivityLog {
  id: string;
  user_id: string | null;
  activity_type: ActivityType;
  description: string;
  metadata: Json | null;
  created_at: string;
}

export function useActivityLogs() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: logs = [], isLoading, error } = useQuery({
    queryKey: ['activity_logs'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('activity_logs')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(100);

      if (error) throw error;
      return data as ActivityLog[];
    },
  });

  const addLogMutation = useMutation({
    mutationFn: async (log: { activity_type: ActivityType; description: string; metadata?: Json }) => {
      const { data: { user } } = await supabase.auth.getUser();
      
      const { data, error } = await supabase
        .from('activity_logs')
        .insert([{
          user_id: user?.id || null,
          activity_type: log.activity_type,
          description: log.description,
          metadata: log.metadata || null,
        }])
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['activity_logs'] });
    },
    onError: (error: Error) => {
      console.error('Failed to add activity log:', error);
    },
  });

  return {
    logs,
    isLoading,
    error,
    addLog: addLogMutation.mutate,
    isAdding: addLogMutation.isPending,
  };
}
