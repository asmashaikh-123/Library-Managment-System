import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { sanitizeErrorMessage } from '@/lib/errorUtils';

export interface Member {
  id: string;
  member_id: string;
  name: string;
  email: string;
  phone: string | null;
  address: string | null;
  membership_type: 'basic' | 'premium' | 'student';
  status: 'active' | 'inactive' | 'suspended';
  join_date: string;
  expiry_date: string | null;
  borrowed_books: number;
  created_at: string;
  updated_at: string;
}

export type MemberInsert = Omit<Member, 'id' | 'created_at' | 'updated_at' | 'member_id' | 'join_date' | 'borrowed_books'>;
export type MemberUpdate = Partial<MemberInsert>;

export function useMembers() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: members = [], isLoading, error } = useQuery({
    queryKey: ['members'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('members')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data as Member[];
    },
  });

  const addMemberMutation = useMutation({
    mutationFn: async (member: MemberInsert) => {
      // Generate member ID
      const { count } = await supabase
        .from('members')
        .select('*', { count: 'exact', head: true });
      
      const memberId = `MEM-${String((count || 0) + 1).padStart(3, '0')}`;

      const { data, error } = await supabase
        .from('members')
        .insert({
          ...member,
          member_id: memberId,
        })
        .select()
        .single();

      if (error) throw error;
      return data as Member;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['members'] });
      toast({ title: 'Member added successfully' });
    },
    onError: (error: Error) => {
      toast({ 
        title: 'Failed to add member', 
        description: sanitizeErrorMessage(error), 
        variant: 'destructive' 
      });
    },
  });

  const updateMemberMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: MemberUpdate }) => {
      const { data, error } = await supabase
        .from('members')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return data as Member;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['members'] });
      toast({ title: 'Member updated successfully' });
    },
    onError: (error: Error) => {
      toast({ 
        title: 'Failed to update member', 
        description: sanitizeErrorMessage(error), 
        variant: 'destructive' 
      });
    },
  });

  const deleteMemberMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('members')
        .delete()
        .eq('id', id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['members'] });
      toast({ title: 'Member deleted successfully' });
    },
    onError: (error: Error) => {
      toast({ 
        title: 'Failed to delete member', 
        description: sanitizeErrorMessage(error), 
        variant: 'destructive' 
      });
    },
  });

  const searchMembers = (query: string) => {
    const lowerQuery = query.toLowerCase();
    return members.filter(member =>
      member.name.toLowerCase().includes(lowerQuery) ||
      member.email.toLowerCase().includes(lowerQuery) ||
      member.member_id.toLowerCase().includes(lowerQuery)
    );
  };

  return {
    members,
    isLoading,
    error,
    addMember: addMemberMutation.mutate,
    updateMember: updateMemberMutation.mutate,
    deleteMember: deleteMemberMutation.mutate,
    searchMembers,
    isAdding: addMemberMutation.isPending,
    isUpdating: updateMemberMutation.isPending,
    isDeleting: deleteMemberMutation.isPending,
  };
}
