import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export interface LibraryStats {
  totalBooks: number;
  totalMembers: number;
  borrowedBooks: number;
  overdueBooks: number;
  todayBorrows: number;
  todayReturns: number;
  totalFines: number;
  collectedFines: number;
}

export function useLibraryStats() {
  const { data: stats, isLoading, error } = useQuery({
    queryKey: ['library_stats'],
    queryFn: async (): Promise<LibraryStats> => {
      const today = new Date().toISOString().split('T')[0];
      
      // Get books count
      const { count: booksCount } = await supabase
        .from('books')
        .select('*', { count: 'exact', head: true });

      // Get total copies sum
      const { data: booksData } = await supabase
        .from('books')
        .select('total_copies');
      const totalBooks = booksData?.reduce((sum, b) => sum + (b.total_copies || 0), 0) || 0;

      // Get active members count
      const { count: membersCount } = await supabase
        .from('members')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'active');

      // Get active borrows
      const { count: borrowedCount } = await supabase
        .from('borrow_records')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'active');

      // Get overdue borrows
      const { count: overdueCount } = await supabase
        .from('borrow_records')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'overdue');

      // Also check active records with past due dates
      const { data: activeRecords } = await supabase
        .from('borrow_records')
        .select('*')
        .eq('status', 'active')
        .lt('due_date', new Date().toISOString());
      
      const actualOverdue = (overdueCount || 0) + (activeRecords?.length || 0);

      // Get today's borrows
      const { count: todayBorrowsCount } = await supabase
        .from('borrow_records')
        .select('*', { count: 'exact', head: true })
        .gte('borrow_date', `${today}T00:00:00`)
        .lt('borrow_date', `${today}T23:59:59`);

      // Get today's returns
      const { count: todayReturnsCount } = await supabase
        .from('borrow_records')
        .select('*', { count: 'exact', head: true })
        .gte('return_date', `${today}T00:00:00`)
        .lt('return_date', `${today}T23:59:59`);

      // Get fines
      const { data: finesData } = await supabase
        .from('borrow_records')
        .select('fine_amount, fine_paid')
        .gt('fine_amount', 0);

      const totalFines = finesData?.reduce((sum, r) => sum + Number(r.fine_amount), 0) || 0;
      const collectedFines = finesData?.filter(r => r.fine_paid).reduce((sum, r) => sum + Number(r.fine_amount), 0) || 0;

      return {
        totalBooks,
        totalMembers: membersCount || 0,
        borrowedBooks: borrowedCount || 0,
        overdueBooks: actualOverdue,
        todayBorrows: todayBorrowsCount || 0,
        todayReturns: todayReturnsCount || 0,
        totalFines,
        collectedFines,
      };
    },
    refetchInterval: 30000, // Refetch every 30 seconds
  });

  return {
    stats: stats || {
      totalBooks: 0,
      totalMembers: 0,
      borrowedBooks: 0,
      overdueBooks: 0,
      todayBorrows: 0,
      todayReturns: 0,
      totalFines: 0,
      collectedFines: 0,
    },
    isLoading,
    error,
  };
}
