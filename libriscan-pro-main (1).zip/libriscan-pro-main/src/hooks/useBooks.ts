import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { sanitizeErrorMessage } from '@/lib/errorUtils';

export interface Book {
  id: string;
  isbn: string;
  title: string;
  author: string;
  publisher: string | null;
  category: string;
  description: string | null;
  cover_image: string | null;
  total_copies: number;
  available_copies: number;
  location: string | null;
  status: 'available' | 'borrowed' | 'reserved' | 'maintenance';
  published_year: number | null;
  created_at: string;
  updated_at: string;
}

export type BookInsert = Omit<Book, 'id' | 'created_at' | 'updated_at'>;
export type BookUpdate = Partial<BookInsert>;

export function useBooks() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: books = [], isLoading, error } = useQuery({
    queryKey: ['books'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('books')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data as Book[];
    },
  });

  const addBookMutation = useMutation({
    mutationFn: async (book: BookInsert) => {
      const { data, error } = await supabase
        .from('books')
        .insert(book)
        .select()
        .single();

      if (error) throw error;
      return data as Book;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['books'] });
      toast({ title: 'Book added successfully' });
    },
    onError: (error: Error) => {
      toast({ 
        title: 'Failed to add book', 
        description: sanitizeErrorMessage(error), 
        variant: 'destructive' 
      });
    },
  });

  const updateBookMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: BookUpdate }) => {
      const { data, error } = await supabase
        .from('books')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return data as Book;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['books'] });
      toast({ title: 'Book updated successfully' });
    },
    onError: (error: Error) => {
      toast({ 
        title: 'Failed to update book', 
        description: sanitizeErrorMessage(error), 
        variant: 'destructive' 
      });
    },
  });

  const deleteBookMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('books')
        .delete()
        .eq('id', id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['books'] });
      toast({ title: 'Book deleted successfully' });
    },
    onError: (error: Error) => {
      toast({ 
        title: 'Failed to delete book', 
        description: sanitizeErrorMessage(error), 
        variant: 'destructive' 
      });
    },
  });

  const findBookByIsbn = (isbn: string) => books.find(book => book.isbn === isbn);

  const searchBooks = (query: string) => {
    const lowerQuery = query.toLowerCase();
    return books.filter(book =>
      book.title.toLowerCase().includes(lowerQuery) ||
      book.author.toLowerCase().includes(lowerQuery) ||
      book.isbn.includes(query) ||
      book.category.toLowerCase().includes(lowerQuery)
    );
  };

  return {
    books,
    isLoading,
    error,
    addBook: addBookMutation.mutate,
    updateBook: updateBookMutation.mutate,
    deleteBook: deleteBookMutation.mutate,
    findBookByIsbn,
    searchBooks,
    isAdding: addBookMutation.isPending,
    isUpdating: updateBookMutation.isPending,
    isDeleting: deleteBookMutation.isPending,
  };
}
