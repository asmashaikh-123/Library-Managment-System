import { createContext, useContext, useState, useCallback, ReactNode } from 'react';

export interface ActivityLog {
  id: string;
  action: 'book_added' | 'book_updated' | 'book_deleted' | 'book_borrowed' | 'book_returned' | 'member_added' | 'member_updated' | 'member_deleted' | 'fine_paid' | 'login' | 'logout' | 'settings_updated';
  description: string;
  user: string;
  timestamp: string;
  details?: Record<string, any>;
}

interface ActivityLogContextType {
  logs: ActivityLog[];
  addLog: (log: Omit<ActivityLog, 'id' | 'timestamp'>) => void;
  clearLogs: () => void;
}

const ActivityLogContext = createContext<ActivityLogContextType | undefined>(undefined);

const initialLogs: ActivityLog[] = [
  {
    id: '1',
    action: 'book_borrowed',
    description: 'Book "Clean Code" borrowed by John Smith',
    user: 'Asma Shaikh',
    timestamp: new Date(Date.now() - 3600000).toISOString(),
    details: { bookId: '1', memberId: '1' },
  },
  {
    id: '2',
    action: 'member_added',
    description: 'New member Mike Davis registered',
    user: 'Asma Shaikh',
    timestamp: new Date(Date.now() - 7200000).toISOString(),
    details: { memberId: '3' },
  },
  {
    id: '3',
    action: 'book_returned',
    description: 'Book "Design Patterns" returned by Mike Davis',
    user: 'Asma Shaikh',
    timestamp: new Date(Date.now() - 86400000).toISOString(),
    details: { bookId: '4', memberId: '3' },
  },
  {
    id: '4',
    action: 'fine_paid',
    description: 'Fine of $5.00 paid by Sarah Johnson',
    user: 'Asma Shaikh',
    timestamp: new Date(Date.now() - 172800000).toISOString(),
    details: { memberId: '2', amount: 5.00 },
  },
  {
    id: '5',
    action: 'book_added',
    description: 'New book "The Pragmatic Programmer" added to library',
    user: 'Asma Shaikh',
    timestamp: new Date(Date.now() - 259200000).toISOString(),
    details: { bookId: '3' },
  },
];

export function ActivityLogProvider({ children }: { children: ReactNode }) {
  const [logs, setLogs] = useState<ActivityLog[]>(initialLogs);

  const addLog = useCallback((log: Omit<ActivityLog, 'id' | 'timestamp'>) => {
    const newLog: ActivityLog = {
      ...log,
      id: Date.now().toString(),
      timestamp: new Date().toISOString(),
    };
    setLogs(prev => [newLog, ...prev]);
  }, []);

  const clearLogs = useCallback(() => {
    setLogs([]);
  }, []);

  return (
    <ActivityLogContext.Provider value={{ logs, addLog, clearLogs }}>
      {children}
    </ActivityLogContext.Provider>
  );
}

export function useActivityLog() {
  const context = useContext(ActivityLogContext);
  if (!context) {
    throw new Error('useActivityLog must be used within an ActivityLogProvider');
  }
  return context;
}
