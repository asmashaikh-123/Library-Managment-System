// Types that map to database schema
import { Database } from '@/integrations/supabase/types';

export type Book = Database['public']['Tables']['books']['Row'];
export type BookInsert = Database['public']['Tables']['books']['Insert'];
export type BookUpdate = Database['public']['Tables']['books']['Update'];

export type Member = Database['public']['Tables']['members']['Row'];
export type MemberInsert = Database['public']['Tables']['members']['Insert'];
export type MemberUpdate = Database['public']['Tables']['members']['Update'];

export type BorrowRecord = Database['public']['Tables']['borrow_records']['Row'];
export type BorrowRecordInsert = Database['public']['Tables']['borrow_records']['Insert'];
export type BorrowRecordUpdate = Database['public']['Tables']['borrow_records']['Update'];

export type ActivityLog = Database['public']['Tables']['activity_logs']['Row'];
export type ActivityLogInsert = Database['public']['Tables']['activity_logs']['Insert'];

export type Notification = Database['public']['Tables']['notifications']['Row'];
export type NotificationInsert = Database['public']['Tables']['notifications']['Insert'];

export interface LibraryStats {
  totalBooks: number;
  totalMembers: number;
  borrowedBooks: number;
  overdueBooks: number;
  todayBorrows: number;
  todayReturns: number;
  totalFines: number;
  collectedFines: number;
}

// Extended types for UI display with joined data
export interface BorrowRecordWithDetails extends BorrowRecord {
  books?: {
    title: string;
    isbn: string;
  } | null;
  members?: {
    name: string;
    member_id: string;
  } | null;
}
