import { useState } from 'react';
import { Header } from '@/components/layout/Header';
import { useActivityLogs } from '@/hooks/useActivityLogs';
import { Search, Filter, Clock, BookOpen, Users, DollarSign, LogIn, LogOut, Loader2 } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { cn } from '@/lib/utils';
import { format, formatDistanceToNow } from 'date-fns';
import { Database } from '@/integrations/supabase/types';

type ActivityType = Database['public']['Enums']['activity_type'];

const actionIcons: Record<ActivityType, React.ReactNode> = {
  book_added: <BookOpen className="h-4 w-4" />,
  book_updated: <BookOpen className="h-4 w-4" />,
  book_deleted: <BookOpen className="h-4 w-4" />,
  book_borrowed: <BookOpen className="h-4 w-4" />,
  book_returned: <BookOpen className="h-4 w-4" />,
  member_added: <Users className="h-4 w-4" />,
  member_updated: <Users className="h-4 w-4" />,
  member_deleted: <Users className="h-4 w-4" />,
  fine_paid: <DollarSign className="h-4 w-4" />,
  login: <LogIn className="h-4 w-4" />,
  logout: <LogOut className="h-4 w-4" />,
};

const actionColors: Record<ActivityType, string> = {
  book_added: 'bg-success/10 text-success border-success/20',
  book_updated: 'bg-primary/10 text-primary border-primary/20',
  book_deleted: 'bg-destructive/10 text-destructive border-destructive/20',
  book_borrowed: 'bg-accent/10 text-accent border-accent/20',
  book_returned: 'bg-success/10 text-success border-success/20',
  member_added: 'bg-success/10 text-success border-success/20',
  member_updated: 'bg-primary/10 text-primary border-primary/20',
  member_deleted: 'bg-destructive/10 text-destructive border-destructive/20',
  fine_paid: 'bg-accent/10 text-accent border-accent/20',
  login: 'bg-primary/10 text-primary border-primary/20',
  logout: 'bg-muted text-muted-foreground border-muted',
};

export default function ActivityLogs() {
  const { logs, isLoading } = useActivityLogs();
  const [searchQuery, setSearchQuery] = useState('');
  const [actionFilter, setActionFilter] = useState('all');

  const filteredLogs = logs.filter(log => {
    const matchesSearch = log.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesAction = actionFilter === 'all' || log.activity_type === actionFilter;
    return matchesSearch && matchesAction;
  });

  return (
    <div className="min-h-screen">
      <Header title="Activity Logs" subtitle="Track all system activities and changes" />

      <div className="p-6 space-y-6">
        {/* Toolbar */}
        <div className="flex flex-wrap items-center gap-4">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search activities..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>
          
          <Select value={actionFilter} onValueChange={setActionFilter}>
            <SelectTrigger className="w-[180px]">
              <Filter className="mr-2 h-4 w-4" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Actions</SelectItem>
              <SelectItem value="book_added">Book Added</SelectItem>
              <SelectItem value="book_borrowed">Book Borrowed</SelectItem>
              <SelectItem value="book_returned">Book Returned</SelectItem>
              <SelectItem value="member_added">Member Added</SelectItem>
              <SelectItem value="fine_paid">Fine Paid</SelectItem>
              <SelectItem value="login">Login</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Loading State */}
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          /* Activity Timeline */
          <div className="rounded-xl border border-border bg-card shadow-soft overflow-hidden">
            {filteredLogs.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-muted">
                  <Clock className="h-8 w-8 text-muted-foreground" />
                </div>
                <h3 className="mt-4 text-lg font-medium text-foreground">No activities found</h3>
                <p className="mt-1 text-sm text-muted-foreground">
                  Activity logs will appear here as you use the system.
                </p>
              </div>
            ) : (
              <div className="divide-y divide-border">
                {filteredLogs.map((log, index) => (
                  <div
                    key={log.id}
                    className="flex items-start gap-4 p-4 hover:bg-muted/50 transition-colors animate-fade-in"
                    style={{ animationDelay: `${index * 0.05}s` }}
                  >
                    <div className={cn(
                      'flex h-10 w-10 shrink-0 items-center justify-center rounded-full border',
                      actionColors[log.activity_type]
                    )}>
                      {actionIcons[log.activity_type]}
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground">{log.description}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="secondary" className="text-xs">
                          {log.activity_type.replace(/_/g, ' ')}
                        </Badge>
                      </div>
                    </div>
                    
                    <div className="text-right shrink-0">
                      <p className="text-xs text-muted-foreground">
                        {log.created_at && formatDistanceToNow(new Date(log.created_at), { addSuffix: true })}
                      </p>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {log.created_at && format(new Date(log.created_at), 'MMM d, h:mm a')}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
