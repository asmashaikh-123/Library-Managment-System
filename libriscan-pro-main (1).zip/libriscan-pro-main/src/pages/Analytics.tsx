import { Header } from '@/components/layout/Header';
import { useBooks } from '@/hooks/useBooks';
import { useMembers } from '@/hooks/useMembers';
import { useBorrowRecords } from '@/hooks/useBorrowRecords';
import { useLibraryStats } from '@/hooks/useLibraryStats';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { TrendingUp, TrendingDown, BookOpen, Users, ArrowRightLeft, DollarSign, BarChart3, PieChart } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart as RechartsPie, Pie, Cell, LineChart, Line, Legend } from 'recharts';

export default function Analytics() {
  const { books } = useBooks();
  const { members } = useMembers();
  const { borrowRecords } = useBorrowRecords();
  const { stats } = useLibraryStats();

  // Calculate category distribution
  const categoryData = books.reduce((acc, book) => {
    const existing = acc.find(item => item.name === book.category);
    if (existing) {
      existing.value += book.total_copies;
    } else {
      acc.push({ name: book.category, value: book.total_copies });
    }
    return acc;
  }, [] as { name: string; value: number }[]);

  // Calculate membership distribution
  const membershipData = [
    { name: 'Basic', value: members.filter(m => m.membership_type === 'basic').length },
    { name: 'Premium', value: members.filter(m => m.membership_type === 'premium').length },
    { name: 'Student', value: members.filter(m => m.membership_type === 'student').length },
  ];

  // Monthly borrowing trends (mock data)
  const monthlyTrends = [
    { month: 'Jul', borrowed: 45, returned: 42 },
    { month: 'Aug', borrowed: 52, returned: 48 },
    { month: 'Sep', borrowed: 61, returned: 55 },
    { month: 'Oct', borrowed: 58, returned: 62 },
    { month: 'Nov', borrowed: 73, returned: 65 },
    { month: 'Dec', borrowed: 68, returned: 70 },
  ];

  // Fine collection data (mock)
  const fineData = [
    { month: 'Jul', amount: 125 },
    { month: 'Aug', amount: 85 },
    { month: 'Sep', amount: 150 },
    { month: 'Oct', amount: 95 },
    { month: 'Nov', amount: 180 },
    { month: 'Dec', amount: 110 },
  ];

  const COLORS = ['hsl(239, 84%, 67%)', 'hsl(38, 92%, 50%)', 'hsl(142, 76%, 36%)', 'hsl(0, 84%, 60%)'];

  // Calculate total fines
  const totalFines = borrowRecords.reduce((sum, r) => sum + (r.fine_amount || 0), 0);
  const overduePercentage = stats.borrowedBooks > 0 ? ((stats.overdueBooks / stats.borrowedBooks) * 100).toFixed(1) : '0';

  return (
    <div className="min-h-screen">
      <Header title="Analytics" subtitle="Library performance metrics and insights" />

      <div className="p-6 space-y-6">
        {/* Quick Stats */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card className="animate-slide-up">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Books</p>
                  <p className="text-3xl font-bold text-foreground">{stats.totalBooks}</p>
                </div>
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary">
                  <BookOpen className="h-6 w-6" />
                </div>
              </div>
              <div className="mt-2 flex items-center gap-1 text-sm text-success">
                <TrendingUp className="h-4 w-4" />
                <span>+12% this month</span>
              </div>
            </CardContent>
          </Card>

          <Card className="animate-slide-up" style={{ animationDelay: '0.1s' }}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Active Members</p>
                  <p className="text-3xl font-bold text-foreground">{stats.totalMembers}</p>
                </div>
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-accent/10 text-accent">
                  <Users className="h-6 w-6" />
                </div>
              </div>
              <div className="mt-2 flex items-center gap-1 text-sm text-success">
                <TrendingUp className="h-4 w-4" />
                <span>+8% this month</span>
              </div>
            </CardContent>
          </Card>

          <Card className="animate-slide-up" style={{ animationDelay: '0.2s' }}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Books in Circulation</p>
                  <p className="text-3xl font-bold text-foreground">{stats.borrowedBooks}</p>
                </div>
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-success/10 text-success">
                  <ArrowRightLeft className="h-6 w-6" />
                </div>
              </div>
              <div className="mt-2 flex items-center gap-1 text-sm text-destructive">
                <TrendingDown className="h-4 w-4" />
                <span>{overduePercentage}% overdue</span>
              </div>
            </CardContent>
          </Card>

          <Card className="animate-slide-up" style={{ animationDelay: '0.3s' }}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Fines</p>
                  <p className="text-3xl font-bold text-foreground">${totalFines.toFixed(2)}</p>
                </div>
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-destructive/10 text-destructive">
                  <DollarSign className="h-6 w-6" />
                </div>
              </div>
              <div className="mt-2 flex items-center gap-1 text-sm text-muted-foreground">
                <span>{stats.overdueBooks} overdue books</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Charts Row */}
        <div className="grid gap-6 lg:grid-cols-2">
          {/* Borrowing Trends */}
          <Card className="animate-slide-up" style={{ animationDelay: '0.4s' }}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-primary" />
                Borrowing Trends
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={monthlyTrends}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" />
                    <YAxis stroke="hsl(var(--muted-foreground))" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px',
                      }}
                    />
                    <Legend />
                    <Bar dataKey="borrowed" fill="hsl(239, 84%, 67%)" name="Borrowed" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="returned" fill="hsl(142, 76%, 36%)" name="Returned" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Category Distribution */}
          <Card className="animate-slide-up" style={{ animationDelay: '0.5s' }}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <PieChart className="h-5 w-5 text-accent" />
                Book Categories
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <RechartsPie>
                    <Pie
                      data={categoryData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={100}
                      paddingAngle={4}
                      dataKey="value"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {categoryData.map((_, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px',
                      }}
                    />
                  </RechartsPie>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Second Row */}
        <div className="grid gap-6 lg:grid-cols-2">
          {/* Fine Collection Trend */}
          <Card className="animate-slide-up" style={{ animationDelay: '0.6s' }}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="h-5 w-5 text-destructive" />
                Fine Collection Trend
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[250px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={fineData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" />
                    <YAxis stroke="hsl(var(--muted-foreground))" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px',
                      }}
                      formatter={(value) => [`$${value}`, 'Fine Amount']}
                    />
                    <Line
                      type="monotone"
                      dataKey="amount"
                      stroke="hsl(0, 84%, 60%)"
                      strokeWidth={2}
                      dot={{ fill: 'hsl(0, 84%, 60%)' }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Membership Distribution */}
          <Card className="animate-slide-up" style={{ animationDelay: '0.7s' }}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5 text-success" />
                Membership Distribution
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[250px]">
                <ResponsiveContainer width="100%" height="100%">
                  <RechartsPie>
                    <Pie
                      data={membershipData}
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      dataKey="value"
                      label={({ name, value }) => `${name}: ${value}`}
                    >
                      {membershipData.map((_, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px',
                      }}
                    />
                  </RechartsPie>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}