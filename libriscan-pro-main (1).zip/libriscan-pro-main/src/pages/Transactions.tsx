import { useState } from 'react';
import { Header } from '@/components/layout/Header';
import { BorrowDialog } from '@/components/transactions/BorrowDialog';
import { useBorrowRecords } from '@/hooks/useBorrowRecords';
import { Plus, Search, Filter, RotateCcw, AlertCircle, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { toast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';

export default function Transactions() {
  const { borrowRecords, isLoading, returnBook, isReturning } = useBorrowRecords();
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [borrowDialogOpen, setBorrowDialogOpen] = useState(false);
  const [returningId, setReturningId] = useState<string | null>(null);

  const filteredRecords = borrowRecords.filter(record => {
    const bookTitle = record.books?.title || '';
    const bookIsbn = record.books?.isbn || '';
    const memberName = record.members?.name || '';
    
    const matchesSearch = bookTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      memberName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      bookIsbn.includes(searchQuery);
    const matchesStatus = statusFilter === 'all' || record.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleReturn = async (recordId: string) => {
    setReturningId(recordId);
    const record = borrowRecords.find(r => r.id === recordId);
    returnBook({ recordId });
    toast({ 
      title: 'Book Returned', 
      description: `"${record?.books?.title}" has been returned successfully.` 
    });
    setReturningId(null);
  };

  const statusStyles = {
    active: 'bg-primary/10 text-primary border-primary/20',
    returned: 'bg-success/10 text-success border-success/20',
    overdue: 'bg-destructive/10 text-destructive border-destructive/20',
  };

  const formatDate = (dateString: string) => {
    return format(new Date(dateString), 'MMM d, yyyy');
  };

  return (
    <div className="min-h-screen">
      <Header title="Transactions" subtitle="Manage book borrowing and returns" />

      <div className="p-6 space-y-6">
        {/* Toolbar */}
        <div className="flex flex-wrap items-center gap-4">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search by book, member, or ISBN..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>
          
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[180px]">
              <Filter className="mr-2 h-4 w-4" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="returned">Returned</SelectItem>
              <SelectItem value="overdue">Overdue</SelectItem>
            </SelectContent>
          </Select>

          <Button onClick={() => setBorrowDialogOpen(true)}>
            <Plus className="mr-2 h-4 w-4" />
            New Borrow
          </Button>
        </div>

        {/* Loading State */}
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          /* Transactions Table */
          <div className="rounded-xl border border-border bg-card shadow-soft overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Book</TableHead>
                  <TableHead>Member</TableHead>
                  <TableHead>Borrow Date</TableHead>
                  <TableHead>Due Date</TableHead>
                  <TableHead>Return Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Fine</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredRecords.map((record) => (
                  <TableRow key={record.id} className="animate-fade-in">
                    <TableCell>
                      <div>
                        <p className="font-medium text-foreground">{record.books?.title || 'Unknown'}</p>
                        <p className="text-xs text-muted-foreground">{record.books?.isbn || '-'}</p>
                      </div>
                    </TableCell>
                    <TableCell className="text-foreground">{record.members?.name || 'Unknown'}</TableCell>
                    <TableCell className="text-muted-foreground">{formatDate(record.borrow_date)}</TableCell>
                    <TableCell>
                      <span className={cn(
                        record.status === 'overdue' && 'text-destructive font-medium'
                      )}>
                        {formatDate(record.due_date)}
                      </span>
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {record.return_date ? formatDate(record.return_date) : '-'}
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className={cn('capitalize', statusStyles[record.status])}>
                        {record.status === 'overdue' && <AlertCircle className="mr-1 h-3 w-3" />}
                        {record.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {record.fine_amount && Number(record.fine_amount) > 0 ? (
                        <span className="font-medium text-destructive">${Number(record.fine_amount).toFixed(2)}</span>
                      ) : (
                        '-'
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      {record.status !== 'returned' && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleReturn(record.id)}
                          disabled={isReturning && returningId === record.id}
                          className="gap-1.5"
                        >
                          {isReturning && returningId === record.id ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : (
                            <RotateCcw className="h-4 w-4" />
                          )}
                          Return
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>

            {filteredRecords.length === 0 && (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-muted">
                  <Search className="h-8 w-8 text-muted-foreground" />
                </div>
                <h3 className="mt-4 text-lg font-medium text-foreground">No transactions found</h3>
                <p className="mt-1 text-sm text-muted-foreground">
                  Try adjusting your search or filter.
                </p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Borrow Dialog */}
      <BorrowDialog open={borrowDialogOpen} onOpenChange={setBorrowDialogOpen} />
    </div>
  );
}
