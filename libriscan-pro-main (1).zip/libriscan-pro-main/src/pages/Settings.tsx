import { useState, useEffect } from 'react';
import { Header } from '@/components/layout/Header';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { toast } from '@/hooks/use-toast';
import { useTheme } from '@/contexts/ThemeContext';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Building2, Clock, DollarSign, Bell, Database, Moon, Sun, User, Loader2 } from 'lucide-react';
import { z } from 'zod';

// Validation schemas for settings
const libraryInfoSchema = z.object({
  libraryName: z.string().min(1, 'Library name is required').max(200, 'Library name is too long'),
  email: z.string().email('Invalid email address').max(255, 'Email is too long'),
  phone: z.string().max(20, 'Phone number is too long').optional(),
  address: z.string().max(500, 'Address is too long').optional(),
});

const loanSettingsSchema = z.object({
  loanPeriod: z.number().min(1, 'Minimum 1 day').max(90, 'Maximum 90 days'),
  maxBooks: z.number().min(1, 'Minimum 1 book').max(50, 'Maximum 50 books'),
  renewalLimit: z.number().min(0, 'Cannot be negative').max(10, 'Maximum 10 renewals'),
  gracePeriod: z.number().min(0, 'Cannot be negative').max(14, 'Maximum 14 days'),
});

const fineSettingsSchema = z.object({
  finePerDay: z.number().min(0, 'Cannot be negative').max(100, 'Maximum $100'),
  maxFine: z.number().min(0, 'Cannot be negative').max(1000, 'Maximum $1000'),
});

export default function Settings() {
  const { theme, setTheme } = useTheme();
  const { user } = useAuth();
  const [isSaving, setIsSaving] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  // Form state
  const [libraryName, setLibraryName] = useState('Central Public Library');
  const [contactEmail, setContactEmail] = useState('contact@library.com');
  const [phone, setPhone] = useState('+1 234 567 8900');
  const [address, setAddress] = useState('123 Library Street, City, Country');
  
  const [loanPeriod, setLoanPeriod] = useState(14);
  const [maxBooks, setMaxBooks] = useState(5);
  const [renewalLimit, setRenewalLimit] = useState(2);
  const [gracePeriod, setGracePeriod] = useState(3);
  
  const [finePerDay, setFinePerDay] = useState(0.5);
  const [maxFine, setMaxFine] = useState(25);
  
  const [dueDateReminders, setDueDateReminders] = useState(true);
  const [overdueNotifications, setOverdueNotifications] = useState(true);
  const [newBookAlerts, setNewBookAlerts] = useState(false);

  // Load settings from database
  useEffect(() => {
    const loadSettings = async () => {
      const { data } = await supabase.from('library_settings').select('*');
      if (data) {
        data.forEach((setting) => {
          const value = setting.setting_value;
          switch (setting.setting_key) {
            case 'library_info':
              if (value && typeof value === 'object') {
                setLibraryName((value as any).name || 'Central Public Library');
                setContactEmail((value as any).email || 'contact@library.com');
                setPhone((value as any).phone || '');
                setAddress((value as any).address || '');
              }
              break;
            case 'loan_settings':
              if (value && typeof value === 'object') {
                setLoanPeriod((value as any).loanPeriod || 14);
                setMaxBooks((value as any).maxBooks || 5);
                setRenewalLimit((value as any).renewalLimit || 2);
                setGracePeriod((value as any).gracePeriod || 3);
              }
              break;
            case 'fine_settings':
              if (value && typeof value === 'object') {
                setFinePerDay((value as any).finePerDay || 0.5);
                setMaxFine((value as any).maxFine || 25);
              }
              break;
            case 'notification_settings':
              if (value && typeof value === 'object') {
                setDueDateReminders((value as any).dueDateReminders ?? true);
                setOverdueNotifications((value as any).overdueNotifications ?? true);
                setNewBookAlerts((value as any).newBookAlerts ?? false);
              }
              break;
          }
        });
      }
    };
    loadSettings();
  }, []);

  const validateAndSave = async () => {
    setErrors({});
    const newErrors: Record<string, string> = {};

    // Validate library info
    const libraryInfoResult = libraryInfoSchema.safeParse({
      libraryName,
      email: contactEmail,
      phone: phone || undefined,
      address: address || undefined,
    });
    if (!libraryInfoResult.success) {
      libraryInfoResult.error.errors.forEach(err => {
        newErrors[err.path[0] as string] = err.message;
      });
    }

    // Validate loan settings
    const loanSettingsResult = loanSettingsSchema.safeParse({
      loanPeriod,
      maxBooks,
      renewalLimit,
      gracePeriod,
    });
    if (!loanSettingsResult.success) {
      loanSettingsResult.error.errors.forEach(err => {
        newErrors[err.path[0] as string] = err.message;
      });
    }

    // Validate fine settings
    const fineSettingsResult = fineSettingsSchema.safeParse({
      finePerDay,
      maxFine,
    });
    if (!fineSettingsResult.success) {
      fineSettingsResult.error.errors.forEach(err => {
        newErrors[err.path[0] as string] = err.message;
      });
    }

    // Additional validation: maxFine should be >= finePerDay
    if (maxFine < finePerDay) {
      newErrors.maxFine = 'Maximum fine must be greater than or equal to fine per day';
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      toast({ 
        title: 'Validation Error', 
        description: 'Please fix the errors before saving.',
        variant: 'destructive'
      });
      return;
    }

    setIsSaving(true);
    try {
      // Save settings to database using upsert
      const settingsToSave = [
        {
          setting_key: 'library_info',
          setting_value: { name: libraryName, email: contactEmail, phone, address },
        },
        {
          setting_key: 'loan_settings',
          setting_value: { loanPeriod, maxBooks, renewalLimit, gracePeriod },
        },
        {
          setting_key: 'fine_settings',
          setting_value: { finePerDay, maxFine },
        },
        {
          setting_key: 'notification_settings',
          setting_value: { dueDateReminders, overdueNotifications, newBookAlerts },
        },
      ];

      for (const setting of settingsToSave) {
        const { error } = await supabase
          .from('library_settings')
          .upsert(setting, { onConflict: 'setting_key' });
        
        if (error) throw error;
      }

      toast({ title: 'Settings Saved', description: 'Your preferences have been updated.' });
    } catch (error) {
      console.error('Failed to save settings:', error);
      toast({ 
        title: 'Failed to Save', 
        description: 'An error occurred while saving settings.',
        variant: 'destructive'
      });
    } finally {
      setIsSaving(false);
    }
  };

  const inputClassName = (field: string) => 
    errors[field] ? 'border-destructive focus-visible:ring-destructive' : '';

  return (
    <div className="min-h-screen">
      <Header title="Settings" subtitle="Configure your library management system" />

      <div className="p-6">
        <div className="mx-auto max-w-3xl space-y-8">
          {/* User Profile */}
          <section className="rounded-xl border border-border bg-card p-6 shadow-soft animate-slide-up">
            <div className="flex items-center gap-3 mb-6">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 text-primary">
                <User className="h-5 w-5" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-foreground">User Profile</h2>
                <p className="text-sm text-muted-foreground">Your account information</p>
              </div>
            </div>

            <div className="grid gap-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label>Name</Label>
                  <Input value={user?.name || ''} readOnly className="bg-muted" />
                </div>
                <div className="grid gap-2">
                  <Label>Role</Label>
                  <Input value={user?.role || ''} readOnly className="bg-muted capitalize" />
                </div>
              </div>
              <div className="grid gap-2">
                <Label>Email</Label>
                <Input value={user?.email || ''} readOnly className="bg-muted" />
              </div>
            </div>
          </section>

          {/* Appearance */}
          <section className="rounded-xl border border-border bg-card p-6 shadow-soft animate-slide-up" style={{ animationDelay: '0.05s' }}>
            <div className="flex items-center gap-3 mb-6">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent/10 text-accent">
                {theme === 'dark' ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
              </div>
              <div>
                <h2 className="text-lg font-semibold text-foreground">Appearance</h2>
                <p className="text-sm text-muted-foreground">Customize the look of the application</p>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-foreground">Dark Mode</p>
                <p className="text-sm text-muted-foreground">Switch between light and dark themes</p>
              </div>
              <Switch 
                checked={theme === 'dark'} 
                onCheckedChange={(checked) => setTheme(checked ? 'dark' : 'light')} 
              />
            </div>
          </section>

          {/* Library Information */}
          <section className="rounded-xl border border-border bg-card p-6 shadow-soft animate-slide-up" style={{ animationDelay: '0.1s' }}>
            <div className="flex items-center gap-3 mb-6">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 text-primary">
                <Building2 className="h-5 w-5" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-foreground">Library Information</h2>
                <p className="text-sm text-muted-foreground">Basic details about your library</p>
              </div>
            </div>

            <div className="grid gap-4">
              <div className="grid gap-2">
                <Label htmlFor="library-name">Library Name</Label>
                <Input 
                  id="library-name" 
                  value={libraryName}
                  onChange={(e) => setLibraryName(e.target.value)}
                  maxLength={200}
                  className={inputClassName('libraryName')}
                />
                {errors.libraryName && <p className="text-sm text-destructive">{errors.libraryName}</p>}
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="email">Contact Email</Label>
                  <Input 
                    id="email" 
                    type="email" 
                    value={contactEmail}
                    onChange={(e) => setContactEmail(e.target.value)}
                    maxLength={255}
                    className={inputClassName('email')}
                  />
                  {errors.email && <p className="text-sm text-destructive">{errors.email}</p>}
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input 
                    id="phone" 
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    maxLength={20}
                    className={inputClassName('phone')}
                  />
                  {errors.phone && <p className="text-sm text-destructive">{errors.phone}</p>}
                </div>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="address">Address</Label>
                <Input 
                  id="address" 
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  maxLength={500}
                  className={inputClassName('address')}
                />
                {errors.address && <p className="text-sm text-destructive">{errors.address}</p>}
              </div>
            </div>
          </section>

          {/* Loan Settings */}
          <section className="rounded-xl border border-border bg-card p-6 shadow-soft animate-slide-up" style={{ animationDelay: '0.15s' }}>
            <div className="flex items-center gap-3 mb-6">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent/10 text-accent">
                <Clock className="h-5 w-5" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-foreground">Loan Settings</h2>
                <p className="text-sm text-muted-foreground">Configure borrowing rules and periods</p>
              </div>
            </div>

            <div className="grid gap-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="loan-period">Default Loan Period (days)</Label>
                  <Input 
                    id="loan-period" 
                    type="number" 
                    value={loanPeriod}
                    onChange={(e) => setLoanPeriod(parseInt(e.target.value) || 0)}
                    min={1}
                    max={90}
                    className={inputClassName('loanPeriod')}
                  />
                  {errors.loanPeriod && <p className="text-sm text-destructive">{errors.loanPeriod}</p>}
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="max-books">Max Books per Member</Label>
                  <Input 
                    id="max-books" 
                    type="number" 
                    value={maxBooks}
                    onChange={(e) => setMaxBooks(parseInt(e.target.value) || 0)}
                    min={1}
                    max={50}
                    className={inputClassName('maxBooks')}
                  />
                  {errors.maxBooks && <p className="text-sm text-destructive">{errors.maxBooks}</p>}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="renewal-limit">Renewal Limit</Label>
                  <Input 
                    id="renewal-limit" 
                    type="number" 
                    value={renewalLimit}
                    onChange={(e) => setRenewalLimit(parseInt(e.target.value) || 0)}
                    min={0}
                    max={10}
                    className={inputClassName('renewalLimit')}
                  />
                  {errors.renewalLimit && <p className="text-sm text-destructive">{errors.renewalLimit}</p>}
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="grace-period">Grace Period (days)</Label>
                  <Input 
                    id="grace-period" 
                    type="number" 
                    value={gracePeriod}
                    onChange={(e) => setGracePeriod(parseInt(e.target.value) || 0)}
                    min={0}
                    max={14}
                    className={inputClassName('gracePeriod')}
                  />
                  {errors.gracePeriod && <p className="text-sm text-destructive">{errors.gracePeriod}</p>}
                </div>
              </div>
            </div>
          </section>

          {/* Fine Settings */}
          <section className="rounded-xl border border-border bg-card p-6 shadow-soft animate-slide-up" style={{ animationDelay: '0.2s' }}>
            <div className="flex items-center gap-3 mb-6">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-destructive/10 text-destructive">
                <DollarSign className="h-5 w-5" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-foreground">Fine Settings</h2>
                <p className="text-sm text-muted-foreground">Configure overdue fine rules</p>
              </div>
            </div>

            <div className="grid gap-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="fine-per-day">Fine per Day ($)</Label>
                  <Input 
                    id="fine-per-day" 
                    type="number" 
                    step="0.01" 
                    value={finePerDay}
                    onChange={(e) => setFinePerDay(parseFloat(e.target.value) || 0)}
                    min={0}
                    max={100}
                    className={inputClassName('finePerDay')}
                  />
                  {errors.finePerDay && <p className="text-sm text-destructive">{errors.finePerDay}</p>}
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="max-fine">Maximum Fine ($)</Label>
                  <Input 
                    id="max-fine" 
                    type="number" 
                    step="0.01" 
                    value={maxFine}
                    onChange={(e) => setMaxFine(parseFloat(e.target.value) || 0)}
                    min={0}
                    max={1000}
                    className={inputClassName('maxFine')}
                  />
                  {errors.maxFine && <p className="text-sm text-destructive">{errors.maxFine}</p>}
                </div>
              </div>
            </div>
          </section>

          {/* Notifications */}
          <section className="rounded-xl border border-border bg-card p-6 shadow-soft animate-slide-up" style={{ animationDelay: '0.25s' }}>
            <div className="flex items-center gap-3 mb-6">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-success/10 text-success">
                <Bell className="h-5 w-5" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-foreground">Notifications</h2>
                <p className="text-sm text-muted-foreground">Manage notification preferences</p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium text-foreground">Due Date Reminders</p>
                  <p className="text-sm text-muted-foreground">Send reminder 3 days before due date</p>
                </div>
                <Switch checked={dueDateReminders} onCheckedChange={setDueDateReminders} />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium text-foreground">Overdue Notifications</p>
                  <p className="text-sm text-muted-foreground">Notify members about overdue books</p>
                </div>
                <Switch checked={overdueNotifications} onCheckedChange={setOverdueNotifications} />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium text-foreground">New Book Alerts</p>
                  <p className="text-sm text-muted-foreground">Notify members about new additions</p>
                </div>
                <Switch checked={newBookAlerts} onCheckedChange={setNewBookAlerts} />
              </div>
            </div>
          </section>

          {/* Data Management */}
          <section className="rounded-xl border border-border bg-card p-6 shadow-soft animate-slide-up" style={{ animationDelay: '0.3s' }}>
            <div className="flex items-center gap-3 mb-6">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 text-primary">
                <Database className="h-5 w-5" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-foreground">Data Management</h2>
                <p className="text-sm text-muted-foreground">Backup and export options</p>
              </div>
            </div>

            <div className="flex gap-3">
              <Button variant="outline">Export Data</Button>
              <Button variant="outline">Import Data</Button>
              <Button variant="outline">Create Backup</Button>
            </div>
          </section>

          {/* Save Button */}
          <div className="flex justify-end">
            <Button onClick={validateAndSave} size="lg" disabled={isSaving}>
              {isSaving ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : (
                'Save Changes'
              )}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
