import { useState } from 'react';
import { Header } from '@/components/layout/Header';
import { useBooks } from '@/hooks/useBooks';
import { useMembers } from '@/hooks/useMembers';
import { useBorrowRecords } from '@/hooks/useBorrowRecords';
import { useActivityLogs } from '@/hooks/useActivityLogs';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from '@/hooks/use-toast';
import { BookOpen, RotateCcw, Search, QrCode, AlertCircle, CheckCircle, DollarSign, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { differenceInDays, parseISO, format } from 'date-fns';

const FINE_PER_DAY = 0.50;
const MAX_FINE = 25.00;

export default function IssueReturn() {
  const { books } = useBooks();
  const { members } = useMembers();
  const { borrowRecords, borrowBook, returnBook, isBorrowing, isReturning } = useBorrowRecords();
  const { addLog } = useActivityLogs();
  const { user } = useAuth();

  // Issue state
  const [selectedBookId, setSelectedBookId] = useState('');
  const [selectedMemberId, setSelectedMemberId] = useState('');
  const [isbnSearch, setIsbnSearch] = useState('');

  // Return state
  const [returnSearch, setReturnSearch] = useState('');
  const [returningId, setReturningId] = useState<string | null>(null);

  const availableBooks = books.filter(b => b.available_copies > 0);
  const activeMembers = members.filter(m => m.status === 'active');
  const activeBorrows = borrowRecords.filter(r => r.status !== 'returned');

  const filteredBorrows = activeBorrows.filter(record => {
    const bookTitle = record.books?.title || '';
    const bookIsbn = record.books?.isbn || '';
    const memberName = record.members?.name || '';
    
    return bookTitle.toLowerCase().includes(returnSearch.toLowerCase()) ||
      memberName.toLowerCase().includes(returnSearch.toLowerCase()) ||
      bookIsbn.includes(returnSearch);
  });

  // Calculate fine for a record
  const calculateFine = (dueDate: string): number => {
    const today = new Date();
    const due = parseISO(dueDate);
    const daysOverdue = differenceInDays(today, due);
    
    if (daysOverdue <= 0) return 0;
    
    const fine = daysOverdue * FINE_PER_DAY;
    return Math.min(fine, MAX_FINE);
  };

  const handleIssue = () => {
    if (!selectedBookId || !selectedMemberId) {
      toast({ title: 'Error', description: 'Please select both a book and a member', variant: 'destructive' });
      return;
    }

    const book = books.find(b => b.id === selectedBookId);
    const member = members.find(m => m.id === selectedMemberId);
    
    borrowBook({ bookId: selectedBookId, memberId: selectedMemberId });
    
    addLog({
      activity_type: 'book_borrowed',
      description: `Book "${book?.title}" issued to ${member?.name}`,
      metadata: { bookId: selectedBookId, memberId: selectedMemberId },
    });

    toast({ title: 'Book Issued', description: `"${book?.title}" issued to ${member?.name}` });
    setSelectedBookId('');
    setSelectedMemberId('');
  };

  const handleReturn = (recordId: string) => {
    const record = borrowRecords.find(r => r.id === recordId);
    if (!record) return;

    setReturningId(recordId);
    const fine = calculateFine(record.due_date);
    
    returnBook({ recordId, fineAmount: fine });
    
    addLog({
      activity_type: 'book_returned',
      description: `Book "${record.books?.title}" returned by ${record.members?.name}${fine > 0 ? ` with fine $${fine.toFixed(2)}` : ''}`,
      metadata: { bookId: record.book_id, memberId: record.member_id, fine },
    });

    toast({ 
      title: 'Book Returned', 
      description: fine > 0 
        ? `"${record.books?.title}" returned. Fine: $${fine.toFixed(2)}`
        : `"${record.books?.title}" returned successfully.`
    });
    setReturningId(null);
  };

  // Find book by ISBN
  const foundBook = isbnSearch ? books.find(b => b.isbn === isbnSearch) : null;

  return (
    <div className="min-h-screen">
      <Header title="Issue / Return" subtitle="Manage book checkouts and returns with fine calculation" />

      <div className="p-6">
        <Tabs defaultValue="issue" className="space-y-6">
          <TabsList className="grid w-full max-w-md grid-cols-2">
            <TabsTrigger value="issue" className="gap-2">
              <BookOpen className="h-4 w-4" />
              Issue Book
            </TabsTrigger>
            <TabsTrigger value="return" className="gap-2">
              <RotateCcw className="h-4 w-4" />
              Return Book
            </TabsTrigger>
          </TabsList>

          {/* Issue Tab */}
          <TabsContent value="issue" className="space-y-6">
            <div className="grid gap-6 lg:grid-cols-2">
              {/* ISBN Lookup */}
              <Card className="animate-slide-up">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <QrCode className="h-5 w-5 text-primary" />
                    Quick ISBN Lookup
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      placeholder="Scan or enter ISBN..."
                      value={isbnSearch}
                      onChange={(e) => setIsbnSearch(e.target.value)}
                      className="pl-9"
                    />
                  </div>
                  
                  {foundBook && (
                    <div className="rounded-lg border border-border p-4 bg-muted/50">
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="font-medium text-foreground">{foundBook.title}</h4>
                          <p className="text-sm text-muted-foreground">{foundBook.author}</p>
                          <p className="text-xs text-muted-foreground mt-1">ISBN: {foundBook.isbn}</p>
                        </div>
                        <Badge variant={foundBook.available_copies > 0 ? 'default' : 'destructive'}>
                          {foundBook.available_copies} available
                        </Badge>
                      </div>
                      {foundBook.available_copies > 0 && (
                        <Button
                          size="sm"
                          className="mt-3"
                          onClick={() => setSelectedBookId(foundBook.id)}
                        >
                          Select for Issue
                        </Button>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Issue Form */}
              <Card className="animate-slide-up" style={{ animationDelay: '0.1s' }}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BookOpen className="h-5 w-5 text-accent" />
                    Issue Book
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Select Book</Label>
                    <Select value={selectedBookId} onValueChange={setSelectedBookId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Choose a book..." />
                      </SelectTrigger>
                      <SelectContent>
                        {availableBooks.map(book => (
                          <SelectItem key={book.id} value={book.id}>
                            {book.title} ({book.available_copies} available)
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Select Member</Label>
                    <Select value={selectedMemberId} onValueChange={setSelectedMemberId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Choose a member..." />
                      </SelectTrigger>
                      <SelectContent>
                        {activeMembers.map(member => (
                          <SelectItem key={member.id} value={member.id}>
                            {member.name} ({member.member_id})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <Button onClick={handleIssue} className="w-full" size="lg" disabled={isBorrowing}>
                    {isBorrowing ? (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                      <BookOpen className="mr-2 h-4 w-4" />
                    )}
                    Issue Book
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Return Tab */}
          <TabsContent value="return" className="space-y-6">
            <Card className="animate-slide-up">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <RotateCcw className="h-5 w-5 text-success" />
                  Active Borrowings
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder="Search by book, member, or ISBN..."
                    value={returnSearch}
                    onChange={(e) => setReturnSearch(e.target.value)}
                    className="pl-9"
                  />
                </div>

                {filteredBorrows.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <CheckCircle className="h-12 w-12 mx-auto mb-2 opacity-50" />
                    <p>No active borrowings found</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {filteredBorrows.map(record => {
                      const fine = calculateFine(record.due_date);
                      const isOverdue = record.status === 'overdue' || fine > 0;
                      
                      return (
                        <div
                          key={record.id}
                          className={cn(
                            'flex items-center justify-between rounded-lg border p-4 transition-colors',
                            isOverdue ? 'border-destructive/50 bg-destructive/5' : 'border-border bg-card'
                          )}
                        >
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <h4 className="font-medium text-foreground">{record.books?.title || 'Unknown'}</h4>
                              {isOverdue && (
                                <Badge variant="destructive" className="gap-1">
                                  <AlertCircle className="h-3 w-3" />
                                  Overdue
                                </Badge>
                              )}
                            </div>
                            <p className="text-sm text-muted-foreground">
                              Borrowed by: {record.members?.name || 'Unknown'}
                            </p>
                            <p className="text-xs text-muted-foreground mt-1">
                              Due: {format(new Date(record.due_date), 'MMM d, yyyy')}
                            </p>
                          </div>
                          
                          <div className="flex items-center gap-4">
                            {fine > 0 && (
                              <div className="text-right">
                                <p className="text-xs text-muted-foreground">Fine</p>
                                <p className="font-semibold text-destructive flex items-center gap-1">
                                  <DollarSign className="h-4 w-4" />
                                  {fine.toFixed(2)}
                                </p>
                              </div>
                            )}
                            <Button 
                              onClick={() => handleReturn(record.id)} 
                              variant={isOverdue ? 'destructive' : 'default'}
                              disabled={isReturning && returningId === record.id}
                            >
                              {isReturning && returningId === record.id ? (
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              ) : (
                                <RotateCcw className="mr-2 h-4 w-4" />
                              )}
                              Return
                            </Button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Fine Information */}
            <Card className="animate-slide-up" style={{ animationDelay: '0.1s' }}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-accent" />
                  Fine Policy
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 sm:grid-cols-3">
                  <div className="rounded-lg bg-muted/50 p-4 text-center">
                    <p className="text-2xl font-bold text-primary">${FINE_PER_DAY.toFixed(2)}</p>
                    <p className="text-sm text-muted-foreground">Per day overdue</p>
                  </div>
                  <div className="rounded-lg bg-muted/50 p-4 text-center">
                    <p className="text-2xl font-bold text-accent">${MAX_FINE.toFixed(2)}</p>
                    <p className="text-sm text-muted-foreground">Maximum fine</p>
                  </div>
                  <div className="rounded-lg bg-muted/50 p-4 text-center">
                    <p className="text-2xl font-bold text-success">14</p>
                    <p className="text-sm text-muted-foreground">Days loan period</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
