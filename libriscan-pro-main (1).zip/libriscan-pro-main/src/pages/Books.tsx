import { useState } from 'react';
import { Header } from '@/components/layout/Header';
import { BookCard } from '@/components/books/BookCard';
import { BookDialog } from '@/components/books/BookDialog';
import { BookQRCode } from '@/components/scanner/BookQRCode';
import { useBooks, Book, BookInsert, BookUpdate } from '@/hooks/useBooks';
import { Plus, Search, Filter, QrCode, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

const categories = ['All', 'Programming', 'Fiction', 'Science', 'History', 'Biography', 'Business', 'Self-Help', 'Other'];

export default function Books() {
  const { books, isLoading, addBook, updateBook, deleteBook, isAdding, isUpdating, isDeleting } = useBooks();
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingBook, setEditingBook] = useState<Book | null>(null);
  const [deleteConfirmBook, setDeleteConfirmBook] = useState<Book | null>(null);
  const [qrBook, setQrBook] = useState<Book | null>(null);

  const filteredBooks = books.filter(book => {
    const matchesSearch = book.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      book.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
      book.isbn.includes(searchQuery);
    const matchesCategory = categoryFilter === 'All' || book.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const handleSaveBook = (bookData: Omit<BookInsert, 'id'>) => {
    if (editingBook) {
      updateBook({ id: editingBook.id, updates: bookData as BookUpdate });
    } else {
      addBook(bookData as BookInsert);
    }
    setEditingBook(null);
    setDialogOpen(false);
  };

  const handleDeleteBook = () => {
    if (deleteConfirmBook) {
      deleteBook(deleteConfirmBook.id);
      setDeleteConfirmBook(null);
    }
  };

  return (
    <div className="min-h-screen">
      <Header title="Books" subtitle={`${books.length} books in the library`} />

      <div className="p-6 space-y-6">
        {/* Toolbar */}
        <div className="flex flex-wrap items-center gap-4">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search by title, author, or ISBN..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>
          
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-[180px]">
              <Filter className="mr-2 h-4 w-4" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {categories.map((cat) => (
                <SelectItem key={cat} value={cat}>{cat}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Button onClick={() => { setEditingBook(null); setDialogOpen(true); }} disabled={isAdding}>
            {isAdding ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Plus className="mr-2 h-4 w-4" />}
            Add Book
          </Button>
        </div>

        {/* Loading State */}
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <>
            {/* Books Grid */}
            <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
              {filteredBooks.map((book) => (
                <BookCard
                  key={book.id}
                  book={book}
                  onEdit={(book) => { setEditingBook(book); setDialogOpen(true); }}
                  onDelete={setDeleteConfirmBook}
                  onSelect={setQrBook}
                />
              ))}
            </div>

            {filteredBooks.length === 0 && (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-muted">
                  <Search className="h-8 w-8 text-muted-foreground" />
                </div>
                <h3 className="mt-4 text-lg font-medium text-foreground">No books found</h3>
                <p className="mt-1 text-sm text-muted-foreground">
                  Try adjusting your search or filter to find what you're looking for.
                </p>
              </div>
            )}
          </>
        )}
      </div>

      {/* Book Dialog */}
      <BookDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        book={editingBook}
        onSave={handleSaveBook}
        isLoading={isAdding || isUpdating}
      />

      {/* Delete Confirmation */}
      <AlertDialog open={!!deleteConfirmBook} onOpenChange={() => setDeleteConfirmBook(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Book</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{deleteConfirmBook?.title}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDeleteBook} 
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={isDeleting}
            >
              {isDeleting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* QR Code Dialog */}
      <Dialog open={!!qrBook} onOpenChange={() => setQrBook(null)}>
        <DialogContent className="sm:max-w-[400px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <QrCode className="h-5 w-5" />
              Book QR Code
            </DialogTitle>
          </DialogHeader>
          {qrBook && <BookQRCode book={qrBook} />}
        </DialogContent>
      </Dialog>
    </div>
  );
}
