import { useState } from 'react';
import { Header } from '@/components/layout/Header';
import { QRScanner } from '@/components/scanner/QRScanner';
import { BorrowDialog } from '@/components/transactions/BorrowDialog';
import { useBooks, Book } from '@/hooks/useBooks';
import { BookOpen, User, MapPin, QrCode, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { toast } from '@/hooks/use-toast';

export default function Scanner() {
  const { books } = useBooks();
  const [scannedBook, setScannedBook] = useState<Book | null>(null);
  const [borrowDialogOpen, setBorrowDialogOpen] = useState(false);

  const findBookByIsbn = (isbn: string): Book | undefined => {
    return books.find(b => b.isbn === isbn);
  };

  const handleScan = (result: string) => {
    try {
      // Try to parse as JSON (our QR format)
      const data = JSON.parse(result);
      if (data.type === 'library-book' && data.isbn) {
        const book = findBookByIsbn(data.isbn);
        if (book) {
          setScannedBook(book);
          toast({ title: 'Book Found!', description: `"${book.title}" scanned successfully.` });
        } else {
          toast({ 
            title: 'Book Not Found', 
            description: 'This book is not in our library database.',
            variant: 'destructive'
          });
        }
      }
    } catch {
      // Try as plain ISBN
      const book = findBookByIsbn(result);
      if (book) {
        setScannedBook(book);
        toast({ title: 'Book Found!', description: `"${book.title}" scanned successfully.` });
      } else {
        // Check if it matches any book by ISBN
        const foundBook = books.find(b => b.isbn.includes(result) || result.includes(b.isbn));
        if (foundBook) {
          setScannedBook(foundBook);
          toast({ title: 'Book Found!', description: `"${foundBook.title}" scanned successfully.` });
        } else {
          toast({ 
            title: 'Invalid QR Code', 
            description: 'Could not find a matching book.',
            variant: 'destructive'
          });
        }
      }
    }
  };

  const handleBorrow = () => {
    if (scannedBook) {
      setBorrowDialogOpen(true);
    }
  };

  return (
    <div className="min-h-screen">
      <Header title="QR Scanner" subtitle="Scan book QR codes to quickly look up or process books" />

      <div className="p-6">
        <div className="grid gap-6 lg:grid-cols-2">
          {/* Scanner */}
          <div className="rounded-xl border border-border bg-card p-6 shadow-soft">
            <div className="mb-6 flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-primary-foreground">
                <QrCode className="h-5 w-5" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-foreground">Scan QR Code</h2>
                <p className="text-sm text-muted-foreground">Point camera at a book's QR code</p>
              </div>
            </div>

            <QRScanner onScan={handleScan} />
          </div>

          {/* Result */}
          <div className="rounded-xl border border-border bg-card p-6 shadow-soft">
            <h2 className="mb-6 text-lg font-semibold text-foreground">Scan Result</h2>

            {scannedBook ? (
              <div className="animate-scale-in">
                <div className="flex gap-4">
                  <div className="flex h-32 w-24 flex-shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-primary/20 to-primary/5 text-primary">
                    <span className="text-3xl font-bold">{scannedBook.title[0]}</span>
                  </div>

                  <div className="flex-1">
                    <Badge className={scannedBook.available_copies > 0 ? '' : 'bg-destructive'}>
                      {scannedBook.available_copies > 0 ? 'Available' : 'Unavailable'}
                    </Badge>
                    <h3 className="mt-2 text-xl font-semibold text-foreground">{scannedBook.title}</h3>
                    <p className="text-muted-foreground">{scannedBook.author}</p>

                    <div className="mt-4 space-y-2 text-sm">
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <BookOpen className="h-4 w-4" />
                        <span>ISBN: {scannedBook.isbn}</span>
                      </div>
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <MapPin className="h-4 w-4" />
                        <span>Location: {scannedBook.location}</span>
                      </div>
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <User className="h-4 w-4" />
                        <span>Copies: {scannedBook.available_copies}/{scannedBook.total_copies}</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-6 flex gap-3">
                  <Button
                    onClick={handleBorrow}
                    disabled={scannedBook.available_copies <= 0}
                    className="flex-1"
                  >
                    Borrow Book
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                  <Button variant="outline" onClick={() => setScannedBook(null)}>
                    Clear
                  </Button>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-muted">
                  <BookOpen className="h-8 w-8 text-muted-foreground" />
                </div>
                <h3 className="mt-4 text-lg font-medium text-foreground">No Book Scanned</h3>
                <p className="mt-1 text-sm text-muted-foreground">
                  Scan a book's QR code to see its details here
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Borrow Dialog */}
      <BorrowDialog
        open={borrowDialogOpen}
        onOpenChange={setBorrowDialogOpen}
        preselectedBookId={scannedBook?.id}
      />
    </div>
  );
}