import { Header } from '@/components/layout/Header';
import { StatCard } from '@/components/dashboard/StatCard';
import { RecentActivity } from '@/components/dashboard/RecentActivity';
import { useLibraryStats } from '@/hooks/useLibraryStats';
import { BookOpen, Users, ArrowRightLeft, AlertCircle, TrendingUp, TrendingDown } from 'lucide-react';

export default function Dashboard() {
  const { stats, isLoading } = useLibraryStats();

  return (
    <div className="min-h-screen">
      <Header 
        title="Dashboard" 
        subtitle={`Welcome back! Here's your library overview for ${new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}`}
      />

      <div className="p-6 space-y-6">
        {/* Stats Grid */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard
            title="Total Books"
            value={isLoading ? '-' : stats.totalBooks.toLocaleString()}
            icon={BookOpen}
            variant="primary"
          />
          <StatCard
            title="Active Members"
            value={isLoading ? '-' : stats.totalMembers.toString()}
            icon={Users}
            variant="accent"
          />
          <StatCard
            title="Books Borrowed"
            value={isLoading ? '-' : stats.borrowedBooks.toString()}
            icon={ArrowRightLeft}
            variant="default"
          />
          <StatCard
            title="Overdue Books"
            value={isLoading ? '-' : stats.overdueBooks.toString()}
            icon={AlertCircle}
            variant="warning"
          />
        </div>

        {/* Quick Stats */}
        <div className="grid gap-4 lg:grid-cols-2">
          <div className="rounded-xl border border-border bg-card p-6 shadow-soft">
            <h3 className="text-lg font-semibold text-foreground">Today's Summary</h3>
            <p className="text-sm text-muted-foreground">Quick overview of today's activities</p>
            
            <div className="mt-6 grid grid-cols-2 gap-6">
              <div className="flex items-center gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-success/10">
                  <TrendingUp className="h-6 w-6 text-success" />
                </div>
                <div>
                  <p className="text-2xl font-semibold text-foreground">{isLoading ? '-' : stats.todayBorrows}</p>
                  <p className="text-sm text-muted-foreground">Books Borrowed</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
                  <TrendingDown className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-semibold text-foreground">{isLoading ? '-' : stats.todayReturns}</p>
                  <p className="text-sm text-muted-foreground">Books Returned</p>
                </div>
              </div>
            </div>
          </div>

          <RecentActivity />
        </div>
      </div>
    </div>
  );
}
